# SmartDrop A5-P0.7-R1 数字校核修订

状态：单独版本的离线数字修订。原硬件/CAD 仍为 A5-P0.7。实物试验次数 0，实体验证 `NOT_RUN`。

这份包修正原离线核心中 SAFE/退出量未参与校核、退针误差漏项、跨轮旧确认重用的问题，并另附可看见完整 ASCII 减号的修订指南。它不替换原 HTML/PDF/ZIP，不嵌入历史照片或聊天资料，不是制造放行或实体机械联锁。

## 文件与运行

- `source/clearance-core.cjs`：严格、有界、独立范围的间隙计算与固定 CAD 兼容性
- `source/session-core.cjs`：私有状态、轮次/修订绑定的离线动作确认
- `source/pattern-core.cjs`：严格 5×5 的 0/1/2 镜像数据校验
- `tests/`：可直接运行的 Node.js 内置测试
- `guide-content.json`、`build_guide.py`：单独版本指南内容与生成器
- `proof/`：原件指纹、软件测试结果与人工示例输出

运行测试：`node --test tests/*.test.cjs`（Node.js 20 或更新版本，无第三方 JavaScript 依赖）

重建 PDF 另需 Python 3、ReportLab、DejaVu Sans/Mono 字体与中文 CID 字体支持；生成器当前使用 Linux 系统字体路径。现成 PDF 可直接阅读。

新版数值 API：

```js
const { makeSyntheticExample, evaluateClearances } = require('./source/clearance-core.cjs');
const input = makeSyntheticExample(); // 人工 fixture，不是实测默认值
const result = evaluateClearances(input);
console.log(result);
```

不要用人工 fixture 替补未知测量。每项输入更新后重新计算；保存/展示输入指纹可检测旧结果。数值屏幕、固定 CAD 兼容与实体验证始终分开。输出里不存在旧版的无范围 `allPass`。

## 会话 API

```js
const { createSession } = require('./source/session-core.cjs');
const session = createSession({ oldColorPresent: true }); // 明确选取示意场景
const s = session.snapshot();
const next = session.advance({
  type: 'clamp',
  sessionId: s.sessionId,
  cycleId: s.cycleId,
  expectedRevision: s.revision,
  ack: { simulationOnly: true, clampSecured: true, safeSupportsInPlace: true }
});
```

`sessionId` 为随机 UUID，只用于防止误混用会话，并非抵御恶意宿主代码的秘密。快照深冻结且不能被传回覆盖私有状态。所有被拒绝命令保持状态和计数不变；`revision` 每次成功事件加一，`cycleId` 只在新循环或故障复位时加一，永不自动回绕。

正常事件顺序：

`clamp → drop → hold_ok → withdraw → remove_blocks → lower → retract_ok → lift → replace_blocks → away → new_cycle`

前八步到 `LIFTED`，尚未完成重新支承和离开工件。只有完成后两步才能开始新循环；旧轮持豆和退针确认全部清空。`FAULTED` 只能用独立恢复终点的 `safe_reset` 复位，不允许普通前后步骤越过故障。

每个事件的 `ack` 必须恰好包含 `simulationOnly: true` 和以下字段：

| 事件 | 其他字段 |
| --- | --- |
| clamp | clampSecured, safeSupportsInPlace |
| drop | cupLowered, boxStationary, tiltChecked |
| hold_ok | holdingChecked, noDropInModel |
| withdraw | drawerFullyWithdrawn, sweepClear |
| remove_blocks | supportsRemoved |
| lower | transferHeightChecked |
| retract_ok | needleRetractionChecked, beadReleaseChecked |
| lift | retractionMaintained, liftToSafeHeight |
| replace_blocks | reSupported |
| away | awayFromWorkpiece, oldColorCheck |
| new_cycle | awayFromWorkpiece, reSupported, oldColorPresent |
| fault_stop | stopRequested |
| safe_reset | awayFromWorkpiece, reSupported, faultAddressed, oldColorPresent |

除 `oldColorPresent` 为明确布尔值、`oldColorCheck` 为模型场景对应的 `UNCHANGED` 或 `NOT_APPLICABLE` 外，均只能是字面布尔值 `true`。这些均是离线确认，不是观察数据。`oldColorUnmoved` 永远为 null；`physicalTest=false`、`hardwareTestCount=0`、`hardwareTestStatus=NOT_RUN` 不随点击改变。

## 固定 CAD 与适用范围

原名义底板 world Z=15、SAFE=26、转印高=5.55；杯底初始 world Z=30，抽屉中央顶 Z=23，因此下降量还受上界约束。原规定 D=6、W=110、R=2.10、L=1.65 mm，修改数字不会修改固定支架或生成新的 CAD。

92 mm 是抽屉移动构件与下降构件包络的保守 Y 分离阈值，不是已证实的机械最短行程；现有命名退出姿态仍为 110 mm。大于或等于 158 mm 时原轨道名义重叠消失，但更小值也不自动证明强度与稳定。

原模型仅有 145×145 mm 底板和中心 5×5 柱场，必须另查全扫掠障碍/最高空柱。两点螺杆高度差不是全杯沿倾斜上界。共同基准误差和直接组合间隙不能重复扣除，也不能无依据抵消。

## 不兼容的旧行为

- 新数值 API 不会接受随意数字字符串、空白或忽略拼错字段
- 旧 `blank()/advance(state,event)` 的自由可写状态不再用于新会话
- 旧数值阶段号不适用；使用明确状态名
- 旧保存的状态 JSON 只能作为历史显示，不能解锁新会话
- 局部数学通过不能升级为真实保持力、退针、对位或整机通过

## 保留证据

`proof/original-artifacts.json` 记录三份历史 HTML/PDF/ZIP 的原字节数与 SHA-256。新包不得整包复制历史嵌套原件，以免带入与本轮数字修订无关的个人资料。更多原始背景保留在历史项目档案中，不在本包内重复嵌入。
