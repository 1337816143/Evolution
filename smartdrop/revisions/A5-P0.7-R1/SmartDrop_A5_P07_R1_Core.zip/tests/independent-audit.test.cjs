'use strict';
// Independent adversarial review. Synthetic software checks only: hardware NOT_RUN.
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../source/clearance-core.cjs');
const {createSession} = require('../source/session-core.cjs');
const {mirror} = require('../source/pattern-core.cjs');
const units = s => Math.round(Number(s) * 1000);
const mm = n => (n / 1000).toFixed(3);
const resultMargins = r => Object.fromEntries(C.PREDICATES.map(k => [k, r.predicates[k].signedMarginMm]));
const f = () => C.makeSyntheticExample();
const base = C.evaluateClearances(f());
function directFixture() {
  const x=f();
  for(const p of C.PREDICATES) {
    x.effective.routes[p]='DIRECT_LOWER_GAP';
    x.effective.directGaps[p]=base.predicates[p].lowerGapBeforeMarginMm;
  }
  return x;
}
let seed=0x51a73db9;
function random(n) { seed=(Math.imul(seed,1664525)+1013904223)>>>0; return seed%n; }

// Independent integer-micrometre oracle. Test ranges stay within exact JS integers.
function oracle(x) {
  const v=Object.fromEntries(Object.entries(x.effective.values).map(([k,s])=>[k,units(s)]));
  const m=Object.fromEntries(Object.entries(x.margins).map(([k,s])=>[k,units(s)]));
  const lowerS=v.S-v.U_S_minus, upperS=v.S+v.U_S_plus;
  const upperL=v.L+v.U_L_plus, lowerR=v.R-v.U_R_minus;
  const lowerFace=v.Fsafe-v.U_Fsafe_minus, upperFace=v.Fsafe+v.U_Fsafe_plus;
  const upperDrop=v.D+v.U_D_plus, lowerDrop=v.D-v.U_D_minus;
  const cup=v.CupLoadBottom-v.U_CupLoadBottom_minus-upperDrop-v.T_down;
  return {
    oldFaceClear:lowerS-v.H_old_max-m.c_old,
    tipPegClear:lowerS-upperL-v.P_transfer_max-m.c_tip,
    capture:v.P_transfer_min+v.H_new_min-upperS-m.c_capture,
    retractClear:lowerR-upperL-m.c_retract,
    safeBlockerClear:lowerFace+v.Kcar-v.U_Kcar_minus-(v.Zblocker+v.U_Zblocker_plus)-m.c_safe,
    safeTopClear:v.HeadCeiling-v.U_HeadCeiling_minus-(upperFace+v.KcarTop+v.U_KcarTop_plus)-m.c_top,
    guardRimClear:lowerFace-v.H_new_max-(v.RimLoadTop+v.U_RimLoadTop_plus-lowerDrop+v.T_up)-m.c_guard,
    cupSledClear:cup-(v.SledFloorTop+v.U_SledFloorTop_plus)-m.c_cup,
    cupBoardClear:cup-(v.BoardTop+v.U_BoardTop_plus+v.ObstacleCup_max)-m.c_board,
    drawerClear:v.DrawerBottom-v.U_DrawerBottom_minus-(v.BoardTop+v.U_BoardTop_plus+Math.max(v.H_old_sweep_max,v.P_sweep_max,v.Feature_sweep_max))-m.c_drawer,
    railClear:v.RailBottom-v.U_RailBottom_minus-(v.BoardTop+v.U_BoardTop_plus+Math.max(v.P_rail_max,v.Feature_rail_max,x.effective.scope.noOldBeadsInRail?0:v.H_old_rail_max))-m.c_rail,
    withdrawClear:v.W-v.U_W_minus-92000-v.U_Y-m.c_W
  };
}
test('INDEPENDENT: 1500 deterministic random component cases match a separate integer oracle',()=>{
  for(let iteration=0;iteration<1500;iteration++) {
    const x=f();
    for(const k of C.INPUT_SCHEMA.valueKeys) x.effective.values[k]=mm(random(k.startsWith('U_')||k.startsWith('T_')?800:120001));
    for(const [lo,hi] of [['H_new_min','H_new_max'],['P_transfer_min','P_transfer_max'],['Kcar','KcarTop']]) {
      const a=units(x.effective.values[lo]), b=units(x.effective.values[hi]);
      x.effective.values[lo]=mm(Math.min(a,b)); x.effective.values[hi]=mm(Math.max(a,b));
    }
    x.effective.scope.noOldBeadsInRail=false;
    for(const k of C.INPUT_SCHEMA.marginKeys) x.margins[k]=mm(random(2001));
    const want=oracle(x), r=C.evaluateClearances(x);
    assert.equal(r.inputValidation,'VALID');
    for(const p of C.PREDICATES) {
      assert.equal(r.predicates[p].signedMarginMm,mm(want[p]),`${iteration}: ${p}`);
      assert.equal(r.predicates[p].status,want[p]>=0?'CERTIFIED':'NOT_CERTIFIED');
    }
    assert.equal(r.scopedNumericScreenPass,Object.values(want).every(v=>v>=0));
    assert.equal(r.physicalValidation,'NOT_RUN');
  }
});
test('INDEPENDENT: all 4096 direct/component route combinations preserve equivalent gaps',()=>{
  const expected=resultMargins(base);
  for(let mask=0;mask<4096;mask++) {
    const x=f();
    C.PREDICATES.forEach((p,i)=>{if(mask&(1<<i)) {
      x.effective.routes[p]='DIRECT_LOWER_GAP';
      x.effective.directGaps[p]=base.predicates[p].lowerGapBeforeMarginMm;
    }});
    const r=C.evaluateClearances(x);
    assert.deepEqual(resultMargins(r),expected,`mask ${mask}`);
    assert.equal(r.scopedNumericScreenPass,true);
    assert.equal(r.physicalValidation,'NOT_RUN');
  }
});
test('INDEPENDENT: every direct predicate rejects minus 0.001 exactly at its design boundary',()=>{
  const marginKeys=['c_old','c_tip','c_capture','c_retract','c_safe','c_top','c_guard','c_cup','c_board','c_drawer','c_rail','c_W'];
  C.PREDICATES.forEach((p,i)=>{
    for(const offset of [-1,0,1]) {
      const x=directFixture(); x.effective.directGaps[p]=mm(units(x.margins[marginKeys[i]])+offset);
      const r=C.evaluateClearances(x);
      assert.equal(r.predicates[p].signedMarginMm,mm(offset));
      assert.equal(r.predicates[p].status,offset<0?'NOT_CERTIFIED':'CERTIFIED');
      assert.equal(r.scopedNumericScreenPass,offset>=0);
    }
  });
});
test('INDEPENDENT: malformed numeric scalars fail every numeric location, even on unused routes',()=>{
  const locations=[
    ...C.INPUT_SCHEMA.valueKeys.map(k=>['effective','values',k]),
    ...C.INPUT_SCHEMA.marginKeys.map(k=>['margins',k]),
    ...C.PREDICATES.map(k=>['effective','directGaps',k]),
    ...Object.keys(C.CAD_PROFILE.nominal).map(k=>['nominal',k]),
    ['effective','worldDatum','commonErrorMinus'],['effective','worldDatum','commonErrorPlus']
  ];
  const invalid=[null,true,false,'',' ',NaN,Infinity,-Infinity,'12mm','0x10','1e0','1.0001',[],{},new Number(2),1n,Symbol('bad')];
  for(const path of locations) for(const value of invalid) {
    const x=directFixture(); let obj=x; for(const k of path.slice(0,-1))obj=obj[k]; obj[path.at(-1)]=value;
    const r=C.evaluateClearances(x);
    assert.equal(r.inputValidation,'INVALID',`${path.join('.')} ${String(value)}`);
    assert.equal(r.scopedNumericScreenPass,false);
    assert.equal(r.physicalValidation,'NOT_RUN');
  }
});
test('INDEPENDENT: inactive route metadata may be absent but supplied malformed fields are invalid',()=>{
  const mutations=[
    x=>x.effective.worldDatum.id=false,
    x=>x.effective.worldDatum.commonErrorMinus='-0.001',
    x=>x.effective.worldDatum.commonErrorPlus='',
    x=>x.effective.scope.noOldBeadsInRail='yes'
  ];
  for(const mutate of mutations) {const x=directFixture();mutate(x);const r=C.evaluateClearances(x);assert.equal(r.inputValidation,'INVALID');assert.equal(r.scopedNumericScreenPass,false);}
});
test('INDEPENDENT: independently derived guard drop window endpoints are exact',()=>{
  // Fixture lower D = 5.950 from rim; upper D = 6.550 from world30-D-world23.
  for(const [drop,pass,guard,cup] of [['5.949',false,'-0.001','0.601'],['5.950',true,'0.000','0.600'],['6.550',true,'0.600','0.000'],['6.551',false,'0.601','-0.001']]) {
    const x=f();x.effective.values.D=drop;const r=C.evaluateClearances(x);
    assert.equal(r.predicates.guardRimClear.signedMarginMm,guard);
    assert.equal(r.predicates.cupSledClear.signedMarginMm,cup);
    assert.equal(r.scopedNumericScreenPass,pass);
  }
});
test('INDEPENDENT: shared world datum offsets and common error do not change any physical gap',()=>{
  const coordinates=['Fsafe','Zblocker','HeadCeiling','RimLoadTop','CupLoadBottom','SledFloorTop','BoardTop','DrawerBottom','RailBottom'];
  for(const shift of [-500000,-123001,0,17853,700000]) {
    const x=f();for(const k of coordinates)x.effective.values[k]=mm(units(x.effective.values[k])+shift);
    x.effective.worldDatum.commonErrorMinus='15.713';x.effective.worldDatum.commonErrorPlus='77.014';
    assert.deepEqual(resultMargins(C.evaluateClearances(x)),resultMargins(base));
  }
});
test('INDEPENDENT: missing component bounds never become zero; direct bound may replace required components',()=>{
  for(const k of C.INPUT_SCHEMA.valueKeys.filter(k=>k!=='H_old_rail_max')) {
    const x=f();delete x.effective.values[k];const r=C.evaluateClearances(x);
    assert.equal(r.scopedNumericScreenPass,false,k);
    assert.equal(r.inputValidation,'INCOMPLETE',k);
  }
  const x=directFixture();x.effective.values={};delete x.effective.worldDatum;delete x.effective.scope.noOldBeadsInRail;
  assert.equal(C.evaluateClearances(x).scopedNumericScreenPass,true);
});
const forwards=[['READY','clamp','CLAMPED_SUPPORTED'],['CLAMPED_SUPPORTED','drop','GUARD_LOWERED'],['GUARD_LOWERED','hold_ok','HOLD_ACKNOWLEDGED'],['HOLD_ACKNOWLEDGED','withdraw','DRAWER_WITHDRAWN'],['DRAWER_WITHDRAWN','remove_blocks','BLOCKS_REMOVED'],['BLOCKS_REMOVED','lower','AT_TRANSFER'],['AT_TRANSFER','retract_ok','RETRACTION_ACKNOWLEDGED'],['RETRACTION_ACKNOWLEDGED','lift','LIFTED'],['LIFTED','replace_blocks','SUPPORTED'],['SUPPORTED','away','AWAY']];
const ackFields={clamp:['clampSecured','safeSupportsInPlace'],drop:['cupLowered','boxStationary','tiltChecked'],hold_ok:['holdingChecked','noDropInModel'],withdraw:['drawerFullyWithdrawn','sweepClear'],remove_blocks:['supportsRemoved'],lower:['transferHeightChecked'],retract_ok:['needleRetractionChecked','beadReleaseChecked'],lift:['retractionMaintained','liftToSafeHeight'],replace_blocks:['reSupported'],away:['awayFromWorkpiece','oldColorCheck'],new_cycle:['awayFromWorkpiece','reSupported','oldColorPresent'],fault_stop:['stopRequested'],safe_reset:['awayFromWorkpiece','reSupported','faultAddressed','oldColorPresent']};
function cmd(s,type) {const v=s.snapshot(),ack={simulationOnly:true};for(const key of ackFields[type]||[])ack[key]=key==='oldColorCheck'?(v.modelOldColorPresent?'UNCHANGED':'NOT_APPLICABLE'):key==='oldColorPresent'?v.modelOldColorPresent:true;return {type,sessionId:v.sessionId,cycleId:v.cycleId,expectedRevision:v.revision,ack};}
function invariant(s) {assert.equal(s.oldColorUnmoved,null);assert.equal(s.physicalTest,false);assert.equal(s.hardwareConnected,false);assert.equal(s.hardwareTestCount,0);assert.equal(s.hardwareTestStatus,'NOT_RUN');for(const value of Object.values(s.acknowledgedInCycle))assert.ok(value===null||value===s.cycleId);}
test('INDEPENDENT: 5000 mixed legal/illegal/replayed events match a fresh workflow oracle atomically',()=>{
  const s=createSession({oldColorPresent:true}), foreign=createSession({oldColorPresent:true});
  const events=Object.keys(ackFields);let history=[];
  for(let i=0;i<5000;i++) {
    const before=s.snapshot(), legalForward=forwards.find(v=>v[0]===before.stage);
    const legal=legalForward?.[1]||(before.stage==='AWAY'?'new_cycle':'safe_reset');
    let event=random(3)===0?events[random(events.length)]:legal;
    let c=cmd(s,event), expected=forwards.find(v=>v[0]===before.stage&&v[1]===event)?.[2];
    if(event==='fault_stop'&&before.stage!=='FAULTED')expected='FAULTED';
    if(event==='new_cycle'&&before.stage==='AWAY'||event==='safe_reset'&&before.stage==='FAULTED')expected='READY';
    const attack=random(8);
    if(attack===0&&history.length){c=history[random(history.length)];expected=undefined;}
    if(attack===1){c.sessionId=foreign.snapshot().sessionId;expected=undefined;}
    if(attack===2){c.expectedRevision+=1;expected=undefined;}
    if(attack===3){c.ack.simulationOnly=1;expected=undefined;}
    if(expected) {
      const after=s.advance(c);history.push(c);
      assert.equal(after.stage,expected);assert.equal(after.revision,before.revision+1);
      assert.equal(after.cycleId,before.cycleId+(['new_cycle','safe_reset'].includes(event)?1:0));
      if(expected==='READY'||expected==='FAULTED')assert.ok(Object.values(after.acknowledgedInCycle).every(v=>v===null));
      if(expected==='LIFTED'){assert.equal(after.acknowledgedInCycle.away,null);assert.equal(after.acknowledgedInCycle.reSupported,null);}
    }else{assert.throws(()=>s.advance(c),TypeError);assert.deepEqual(s.snapshot(),before);}
    invariant(s.snapshot());
  }
});
test('INDEPENDENT: every pattern position rejects holes/getters/proxies and 1000 round trips isolate storage',()=>{
  let hooks=0;
  for(let row=0;row<5;row++)for(let col=0;col<5;col++) {
    const p=()=>Array.from({length:5},()=>Array(5).fill(0));
    const a=p();delete a[row][col];assert.throws(()=>mirror(a));
    const b=p();Object.defineProperty(b[row],col,{get(){hooks++;return 1;}});assert.throws(()=>mirror(b));
    const c=p();c[row]=new Proxy(c[row],{ownKeys(){hooks++;throw Error();}});assert.throws(()=>mirror(c));
  }
  assert.equal(hooks,0);
  for(let i=0;i<1000;i++) {
    const p=Array.from({length:5},()=>Array.from({length:5},()=>random(3))), before=structuredClone(p), mirrored=mirror(p);
    assert.deepEqual(mirror(mirrored),p);
    for(let r=0;r<5;r++)assert.notEqual(mirrored[r],p[r]);
    mirrored[0][0]=9;assert.deepEqual(p,before);
  }
});
