'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {createSession, STAGES, EVENTS} = require('../source/session-core.cjs');
const path = ['clamp','drop','hold_ok','withdraw','remove_blocks','lower','retract_ok','lift','replace_blocks','away'];
const keys = {
  clamp:['clampSecured','safeSupportsInPlace'], drop:['cupLowered','boxStationary','tiltChecked'],
  hold_ok:['holdingChecked','noDropInModel'], withdraw:['drawerFullyWithdrawn','sweepClear'],
  remove_blocks:['supportsRemoved'], lower:['transferHeightChecked'], retract_ok:['needleRetractionChecked','beadReleaseChecked'],
  lift:['retractionMaintained','liftToSafeHeight'], replace_blocks:['reSupported'], away:['awayFromWorkpiece','oldColorCheck'],
  new_cycle:['awayFromWorkpiece','reSupported','oldColorPresent'], fault_stop:['stopRequested'],
  safe_reset:['awayFromWorkpiece','reSupported','faultAddressed','oldColorPresent']
};
function command(session,type) {
 const s=session.snapshot(); const ack={simulationOnly:true};
 for(const k of keys[type]||[]) ack[k]= k==='oldColorPresent'?s.modelOldColorPresent:k==='oldColorCheck'?(s.modelOldColorPresent?'UNCHANGED':'NOT_APPLICABLE'):true;
 return {type,sessionId:s.sessionId,cycleId:s.cycleId,expectedRevision:s.revision,ack};
}
function advance(s,e){return s.advance(command(s,e));}
function at(stage,oldColorPresent=true){const s=createSession({oldColorPresent});if(stage==='FAULTED'){advance(s,'fault_stop');return s;}for(const e of path){if(s.snapshot().stage===stage)return s;advance(s,e);}assert.equal(s.snapshot().stage,stage);return s;}
function rejectAtomic(s,c){const before=s.snapshot();assert.throws(()=>s.advance(c),TypeError);assert.deepEqual(s.snapshot(),before);}
function digitalOnly(s){assert.equal(s.hardwareConnected,false);assert.equal(s.physicalTest,false);assert.equal(s.hardwareTestCount,0);assert.equal(s.hardwareTestStatus,'NOT_RUN');assert.equal(s.oldColorUnmoved,null);}
const destinations=['CLAMPED_SUPPORTED','GUARD_LOWERED','HOLD_ACKNOWLEDGED','DRAWER_WITHDRAWN','BLOCKS_REMOVED','AT_TRANSFER','RETRACTION_ACKNOWLEDGED','LIFTED','SUPPORTED','AWAY'];
let allowed=0, forbidden=0;
for(const stage of STAGES)for(const type of EVENTS){
 const index=path.indexOf(type), isForward=index>=0 && stage===(index===0?'READY':destinations[index-1]);
 const legal=isForward||(type==='fault_stop'&&stage!=='FAULTED')||(type==='new_cycle'&&stage==='AWAY')||(type==='safe_reset'&&stage==='FAULTED');
 if(legal)allowed++;else forbidden++;
 test(`OFFLINE matrix ${stage} + ${type}: ${legal?'accepted':'rejected'}`,()=>{
  const s=at(stage), before=s.snapshot(), c=command(s,type);
  if(!legal){rejectAtomic(s,c);return;}
  const after=s.advance(c);digitalOnly(after);assert.equal(after.revision,before.revision+1);
  assert.equal(after.stage,isForward?destinations[index]:type==='fault_stop'?'FAULTED':'READY');
  assert.equal(after.cycleId,before.cycleId+(['new_cycle','safe_reset'].includes(type)?1:0));
 });
}
test('OFFLINE matrix is complete: 23 allowed, 133 forbidden',()=>{assert.equal(allowed,23);assert.equal(forbidden,133);});
test('OFFLINE historical backwards exploit individually rejects after lift',()=>{const s=at('LIFTED');for(const e of ['hold_ok','withdraw','lower','lift'])rejectAtomic(s,command(s,e));});
test('OFFLINE three complete cycles invalidate every old acknowledgment',()=>{
 const s=createSession({oldColorPresent:true});let stale;
 for(let cycle=1;cycle<=3;cycle++){
  assert.equal(s.snapshot().cycleId,cycle);assert.ok(Object.values(s.snapshot().acknowledgedInCycle).every(v=>v===null));
  for(const e of path){if(e==='retract_ok')rejectAtomic(s,command(s,'lift'));const c=command(s,e);const before=s.snapshot();const after=s.advance(c);assert.equal(after.revision,before.revision+1);digitalOnly(after);rejectAtomic(s,c);if(cycle===1&&e==='retract_ok')stale=c;}
  if(cycle>1)rejectAtomic(s,stale);advance(s,'new_cycle');digitalOnly(s.snapshot());assert.equal(s.snapshot().modelOldColorCheck,null);
 }
});
for(const stage of STAGES.filter(s=>s!=='FAULTED')) test(`OFFLINE fault clears confirmations from ${stage}`,()=>{
 const s=at(stage);const before=s.snapshot();const after=advance(s,'fault_stop');assert.equal(after.fault.fromStage,stage);assert.ok(Object.values(after.acknowledgedInCycle).every(v=>v===null));assert.equal(after.modelOldColorCheck,null);digitalOnly(after);
 for(const e of EVENTS.filter(e=>e!=='safe_reset'))rejectAtomic(s,command(s,e));
 const reset=advance(s,'safe_reset');assert.equal(reset.cycleId,before.cycleId+1);assert.equal(reset.revision,before.revision+2);assert.equal(reset.stage,'READY');assert.ok(Object.values(reset.acknowledgedInCycle).every(v=>v===null));digitalOnly(reset);
});
test('OFFLINE command metadata and outer payload reject without coercion',()=>{
 const s=createSession({oldColorPresent:false}); const c=command(s,'clamp');let calls=0;
 const nonnumbers=[undefined,null,true,false,'',' ','0',[],{},new Number(0),1n,Symbol('bad'),NaN,Infinity,-Infinity,{valueOf(){calls++;return 0;},toString(){calls++;return '0';}}];
 for(const field of ['cycleId','expectedRevision'])for(const value of [...nonnumbers,-1,.5,Number.MAX_SAFE_INTEGER+1])rejectAtomic(s,{...c,[field]:value});
 for(const v of [null,[],{},3,'clamp',()=>{},new Date(),Object.create(c)])rejectAtomic(s,v);
 for(const v of [undefined,null,true,1,{},new String('clamp'),' clamp','CLAMP'])rejectAtomic(s,{...c,type:v});
 for(const extra of ['stage','physicalTest','fullyRetracted','oldColorUnmoved','hardwareConnected'])rejectAtomic(s,{...c,[extra]:true});
 for(const field of Object.keys(c)){const x={...c};delete x[field];rejectAtomic(s,x);}
 const getter={...c};Object.defineProperty(getter,'type',{enumerable:true,get(){calls++;return 'clamp';}});rejectAtomic(s,getter);
 rejectAtomic(s,new Proxy(c,{get(){calls++;throw new Error('must not run');},ownKeys(){calls++;throw new Error('must not run');},getPrototypeOf(){calls++;throw new Error('must not run');}}));
 assert.equal(calls,0);
});
test('OFFLINE acknowledgments exact shape, primitive true, and immutable input',()=>{
 for(const type of EVENTS){const stage=type==='safe_reset'?'FAULTED':type==='new_cycle'?'AWAY':type==='fault_stop'?'READY':path.indexOf(type)===0?'READY':destinations[path.indexOf(type)-1];const s=at(stage);const c=command(s,type);
  for(const k of Object.keys(c.ack)){for(const value of [undefined,null,false,'true',1,{},[]]){if(k==='oldColorPresent'&&value===false)continue;rejectAtomic(s,{...c,ack:{...c.ack,[k]:value}});}const ack={...c.ack};delete ack[k];rejectAtomic(s,{...c,ack});}
  rejectAtomic(s,{...c,ack:{...c.ack,physicalTest:true}});let calls=0;const ack={...c.ack};Object.defineProperty(ack,'simulationOnly',{enumerable:true,get(){calls++;return true;}});rejectAtomic(s,{...c,ack});assert.equal(calls,0);
  const original=structuredClone(c);s.advance(c);assert.deepEqual(c,original);
 }
});
test('OFFLINE foreign session, stale cycle, and caller state rejected',()=>{
 const a=createSession({oldColorPresent:true}),b=createSession({oldColorPresent:true});rejectAtomic(b,command(a,'clamp'));
 const historical=a.snapshot();assert.throws(()=>a.advance(historical,'clamp'),TypeError);assert.deepEqual(a.snapshot(),historical);
 const c=command(a,'clamp');for(const e of path)advance(a,e);advance(a,'new_cycle');rejectAtomic(a,{...c,expectedRevision:a.snapshot().revision});rejectAtomic(a,{...c,cycleId:a.snapshot().cycleId});
});
test('OFFLINE snapshots are deep immutable and never operational state',()=>{
 const s=at('RETRACTION_ACKNOWLEDGED');const a=s.snapshot(),b=s.snapshot();assert.notEqual(a,b);assert.notEqual(a.acknowledgedInCycle,b.acknowledgedInCycle);
 for(const mutate of [()=>{a.stage='AWAY';},()=>{a.physicalTest=true;},()=>{a.acknowledgedInCycle.retraction=999;}])assert.throws(mutate,TypeError);
 assert.deepEqual(s.snapshot(),b);rejectAtomic(s,structuredClone(a));digitalOnly(a);
});
test('OFFLINE old-color model fact never becomes hardware evidence',()=>{for(const present of [false,true]){const s=at('SUPPORTED',present);const c=command(s,'away');rejectAtomic(s,{...c,ack:{...c.ack,oldColorCheck:present?'NOT_APPLICABLE':'UNCHANGED'}});advance(s,'away');assert.equal(s.snapshot().modelOldColorCheck,present?'UNCHANGED':'NOT_APPLICABLE');digitalOnly(s.snapshot());}});
test('OFFLINE createSession requires explicit own boolean scenario',()=>{for(const value of [undefined,null,{},[],true,{oldColorPresent:1},{oldColorPresent:'true'},{oldColorPresent:false,physicalTest:true},Object.create({oldColorPresent:true})])assert.throws(()=>createSession(value),TypeError);const s=createSession(Object.assign(Object.create(null),{oldColorPresent:false}));digitalOnly(s.snapshot());});
