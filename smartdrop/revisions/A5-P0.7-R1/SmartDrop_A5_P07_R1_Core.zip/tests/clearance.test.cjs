'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { VERSION, CAD_PROFILE, INPUT_SCHEMA, PREDICATES, evaluateClearances: evaluate, makeSyntheticExample: fixture } = require('../source/clearance-core.cjs');
const clone = x => structuredClone(x);
const set = (x, k, value) => { x.effective.values[k] = value; return x; };
const margin = (x, k) => evaluate(x).predicates[k].signedMarginMm;
const base = evaluate(fixture());
const expected = { oldFaceClear: '0.100', tipPegClear: '0.300', capture: '1.100', retractClear: '0.100', safeBlockerClear: '1.700', safeTopClear: '23.200', guardRimClear: '0.050', cupSledClear: '0.550', cupBoardClear: '3.450', drawerClear: '0.550', railClear: '0.350', withdrawClear: '16.300' };

// No tolerances, floating point epsilon, installed dependencies, or hardware.
test('all explicitly synthetic expected signed margins, window, and status layers', () => {
  assert.equal(VERSION, 'A5-P0.7-R1');
  assert.equal(base.evidenceLabel, 'SYNTHETIC_EXAMPLE');
  assert.equal(base.inputValidation, 'VALID');
  assert.equal(base.fixedCadCompatible, true);
  assert.equal(base.scopedNumericScreenPass, true);
  assert.equal(base.physicalMeasurements, 'NOT_RECEIVED');
  assert.equal(base.physicalValidation, 'NOT_RUN');
  assert.equal(Object.hasOwn(base, 'allPass'), false);
  assert.deepEqual(base.transferWindow, { status: 'NONEMPTY', lowerMm: '5.450', upperMm: '6.650', validWindow: true, withinWindow: true });
  for (const [k, e] of Object.entries(expected)) {
    assert.equal(base.predicates[k].signedMarginMm, e, k);
    assert.equal(base.predicates[k].status, 'CERTIFIED', k);
    assert.ok(base.predicates[k].formula.includes(' - '));
    assert.ok(base.predicates[k].inputKeys.length);
  }
});
test('committed JSON fixture exactly matches factory and inputs are not mutated', () => {
  const committed = require('./fixtures/synthetic-clearance.json');
  assert.deepEqual(committed, fixture());
  const before = clone(committed); evaluate(committed); assert.deepEqual(committed, before);
});
test('immutable fixed profile retains anchors, source hashes, and named body/scope limits', () => {
  assert.ok(Object.isFrozen(CAD_PROFILE)); assert.ok(Object.isFrozen(CAD_PROFILE.anchors));
  assert.throws(() => { CAD_PROFILE.anchors.safeFace = '0'; }, TypeError);
  assert.equal(CAD_PROFILE.anchors.safeFace, '41.000');
  assert.equal(CAD_PROFILE.anchors.cupLoadBottom, '30.000'); assert.equal(CAD_PROFILE.anchors.sledFloorTop, '23.000');
  assert.equal(CAD_PROFILE.sourceSHA256.originalZip, 'ce464848c12491febf28a66552a23d75250fca983ae2ab6a9786ce8b24428965');
  assert.equal(CAD_PROFILE.geometryScope.originalModeledPegField, 'CENTRAL_5X5_ONLY');
});
for (const safe of ['0', '25', '40']) test(`nominal SAFE=${safe} is incompatible; immutable anchors never follow the cassette`, () => {
  const x = fixture(); x.nominal.SAFE = safe;
  const r = evaluate(x);
  assert.equal(r.fixedCadCompatible, false); assert.equal(r.fixedCadStatus, 'INCOMPATIBLE');
  assert.equal(r.nominalGeometry.fixedRimLoadTopWorldMm, '41.000');
  assert.equal(r.nominalGeometry.fixedCupLoadBottomWorldMm, '30.000');
  assert.notEqual(r.nominalGeometry.loadRimContactMismatchMm, '0.000');
  assert.notEqual(r.nominalGeometry.faceToDroppedRimGapMm, base.nominalGeometry.faceToDroppedRimGapMm);
  // Effective evidence is independent, not silently overwritten by nominal edits.
  assert.equal(r.predicates.guardRimClear.signedMarginMm, base.predicates.guardRimClear.signedMarginMm);
});
test('effective SAFE=0 has negative blocker and guard margins and cannot pass', () => {
  const x = set(fixture(), 'Fsafe', '15'); x.nominal.SAFE = '0';
  const r = evaluate(x); assert.equal(r.fixedCadCompatible, false); assert.equal(r.scopedNumericScreenPass, false);
  assert.equal(r.predicates.safeBlockerClear.signedMarginMm, '-24.300'); assert.equal(r.predicates.guardRimClear.signedMarginMm, '-25.950');
});
test('blocker-only clearance just above 24 does not make fixed SAFE supports compatible', () => {
  const x = set(fixture(), 'Fsafe', '39.4'); x.nominal.SAFE = '24.4';
  const r = evaluate(x); assert.equal(r.predicates.safeBlockerClear.status, 'CERTIFIED'); assert.equal(r.fixedCadCompatible, false);
  assert.equal(r.predicates.guardRimClear.status, 'NOT_CERTIFIED');
});
for (const [w, status, e] of [['0','NOT_CERTIFIED','-93.700'], ['92','NOT_CERTIFIED','-1.700'], ['93.699','NOT_CERTIFIED','-0.001'], ['93.700','CERTIFIED','0.000'], ['95','CERTIFIED','1.300']]) {
  test(`conservative withdrawal boundary W=${w}: ${e} mm`, () => {
    const x = set(fixture(), 'W', w); x.nominal.W = w; const r = evaluate(x);
    assert.equal(r.predicates.withdrawClear.status, status); assert.equal(r.predicates.withdrawClear.signedMarginMm, e);
    assert.equal(r.fixedCadCompatible, false); assert.equal(r.physicalValidation, 'NOT_RUN');
  });
}
test('wrong signed and wrong direction withdrawal is invalid, never absolute-valued', () => {
  const a = evaluate(set(fixture(), 'W', '-110')); assert.equal(a.predicates.withdrawClear.status, 'INVALID'); assert.equal(a.scopedNumericScreenPass, false);
  const x = fixture(); x.effective.scope.withdrawalDirection = 'POSITIVE_Y'; const b = evaluate(x);
  assert.equal(b.predicates.withdrawClear.status, 'INVALID'); assert.equal(b.scopedNumericScreenPass, false);
});
for (const [w, overlap] of [['0','116.000'], ['42','116.000'], ['110','48.000'], ['157.999','0.001'], ['158','0.000'], ['200','0.000']]) test(`rail engagement at W=${w} is nominal-only`, () => {
  const x = set(fixture(), 'W', w); x.nominal.W = w; const r = evaluate(x);
  assert.equal(r.railEngagement.nominalAtDeclaredStrokeMm, overlap);
  assert.equal(r.railEngagement.stability, 'NOT_ESTABLISHED');
  if (Number(w) >= 158) { assert.equal(r.railEngagement.status, 'NO_NOMINAL_OVERLAP'); assert.equal(r.fixedCadCompatible, false); }
});
test('retraction R=1.85 fails with declared uncertainty, exact equality only in explicit ideal mode', () => {
  const x = set(fixture(), 'R', '1.85'); assert.equal(margin(x,'retractClear'), '-0.150');
  x.effective.values.U_R_minus = '0'; x.effective.values.U_L_plus = '0';
  const r = evaluate(x); assert.equal(r.predicates.retractClear.signedMarginMm, '0.000'); assert.equal(r.physicalValidation, 'NOT_RUN');
});
for (const key of ['U_R_minus', 'U_L_plus']) test(`missing ${key} is UNKNOWN, explicit zero is valid`, () => {
  const x = fixture(); delete x.effective.values[key]; const r = evaluate(x);
  assert.equal(r.predicates.retractClear.status, 'UNKNOWN'); assert.equal(r.scopedNumericScreenPass, false);
  x.effective.values[key] = '0'; assert.equal(evaluate(x).predicates.retractClear.status, 'CERTIFIED');
});
for (const bad of [null, '', '   ', NaN, Infinity, -Infinity, [], {}, true, false, 'NaN', 'Infinity', '0x10', '1e0', '1.0001', '1.', '.1', '1,0']) {
  test(`reject invalid numeric input ${typeof bad}:${String(bad)}`, () => {
    const r = evaluate(set(fixture(), 'U_R_minus', bad));
    assert.equal(r.inputValidation, 'INVALID'); assert.equal(r.scopedNumericScreenPass, false);
    assert.equal(r.predicates.retractClear.status, 'INVALID'); assert.equal(r.physicalValidation, 'NOT_RUN');
  });
}
test('explicit decimal grammar accepts trimmed numeric strings and finite representable numbers', () => {
  assert.equal(margin(set(fixture(),'R',' +2.100 '),'retractClear'), '0.100');
  assert.equal(margin(set(fixture(),'R',2.1),'retractClear'), '0.100');
  assert.equal(evaluate(set(fixture(),'U_R_minus',0.1+0.2)).inputValidation, 'INVALID');
});
for (const key of INPUT_SCHEMA.valueKeys.filter(k => k.startsWith('U_') || ['T_up','T_down'].includes(k))) test(`nonnegative uncertainty required for ${key}`, () => {
  const r = evaluate(set(fixture(), key, '-0.001')); assert.equal(r.inputValidation, 'INVALID'); assert.equal(r.scopedNumericScreenPass, false);
});
for (const key of INPUT_SCHEMA.marginKeys) test(`nonnegative design margin required for ${key}`, () => {
  const x = fixture(); x.margins[key] = '-0.001'; const r = evaluate(x); assert.equal(r.inputValidation,'INVALID'); assert.equal(r.scopedNumericScreenPass,false);
});
test('all supplied uncertainties are required for their dependent component predicates', () => {
  for (const key of INPUT_SCHEMA.valueKeys.filter(k => k.startsWith('U_'))) {
    const x=fixture(); delete x.effective.values[key]; const r=evaluate(x);
    assert.equal(r.scopedNumericScreenPass,false,key);
    assert.ok(Object.values(r.predicates).some(p=>p.status==='UNKNOWN'),key);
  }
});
test('every adverse uncertainty is monotonically nonimproving for every clearance', () => {
  for (const key of INPUT_SCHEMA.valueKeys.filter(k => k.startsWith('U_') || ['T_up','T_down'].includes(k))) {
    const x=fixture(); x.effective.values[key] = (Number(x.effective.values[key]) + 0.1).toFixed(3); const r=evaluate(x);
    for(const p of PREDICATES) assert.ok(Number(r.predicates[p].signedMarginMm)<=Number(base.predicates[p].signedMarginMm),`${key}: ${p}`);
  }
});
test('bead/peg upper bounds never improve collision clearances; lower bounds never improve capture when decreased', () => {
  for (const [field, predicates] of Object.entries({H_old_max:['oldFaceClear'],H_new_max:['guardRimClear'],P_transfer_max:['tipPegClear'],H_old_sweep_max:['drawerClear'],P_sweep_max:['drawerClear'],Feature_sweep_max:['drawerClear'],P_rail_max:['railClear'],Feature_rail_max:['railClear'],ObstacleCup_max:['cupBoardClear']})) {
    const x=fixture(); x.effective.values[field]=(Number(x.effective.values[field])+6).toFixed(3);
    const r=evaluate(x); for(const p of predicates) assert.ok(Number(r.predicates[p].signedMarginMm)<Number(base.predicates[p].signedMarginMm));
  }
  for(const field of ['H_new_min','P_transfer_min']) {
    const x=fixture(); x.effective.values[field]=(Number(x.effective.values[field])-0.1).toFixed(3); assert.equal(Number(margin(x,'capture')),1);
  }
});
test('independent old/new populations do not leak aliases', () => {
  const o=evaluate(set(fixture(),'H_old_max','5.20')); assert.equal(o.predicates.oldFaceClear.signedMarginMm,'0.000'); assert.equal(o.predicates.guardRimClear.signedMarginMm,'0.050'); assert.equal(o.predicates.capture.signedMarginMm,'1.100');
  const n=evaluate(set(fixture(),'H_new_max','5.20')); assert.equal(n.predicates.guardRimClear.signedMarginMm,'-0.050'); assert.equal(n.predicates.oldFaceClear.signedMarginMm,'0.100');
  const l=evaluate(set(fixture(),'H_new_min','4.80')); assert.equal(l.predicates.capture.signedMarginMm,'1.000'); assert.equal(l.predicates.guardRimClear.signedMarginMm,'0.050');
});
test('raising S improves old-face/tip clearance but worsens capture; lowered S does the reverse', () => {
  for(const step of [-0.1,0.1]) {
    const x=set(fixture(),'S',(5.55+step).toFixed(3)); const r=evaluate(x);
    assert.equal(r.predicates.oldFaceClear.signedMarginMm,(0.1+step).toFixed(3));
    assert.equal(r.predicates.tipPegClear.signedMarginMm,(0.3+step).toFixed(3));
    assert.equal(r.predicates.capture.signedMarginMm,(1.1-step).toFixed(3));
    assert.equal(r.predicates.retractClear.signedMarginMm,'0.100');
  }
});
test('window boundary is exact to 0.001 mm and empty interval cannot pass', () => {
  for (const [s, pass] of [['5.449',false],['5.450',true],['6.650',true],['6.651',false]]) {
    const r=evaluate(set(fixture(),'S',s)); assert.equal(r.transferWindow.withinWindow,pass);
    assert.equal(r.scopedNumericScreenPass,pass);
  }
  const r=evaluate(set(fixture(),'H_old_max','7')); assert.equal(r.transferWindow.status,'EMPTY'); assert.equal(r.transferWindow.validWindow,false); assert.equal(r.scopedNumericScreenPass,false);
});
for(const [min,max] of [['H_new_min','H_new_max'],['P_transfer_min','P_transfer_max'],['Kcar','KcarTop']]) test(`reverse bounds ${min}/${max} are invalid`,()=>{
  const x=fixture(); x.effective.values[min]=(Number(x.effective.values[max])+1).toFixed(3); const r=evaluate(x); assert.equal(r.inputValidation,'INVALID'); assert.equal(r.scopedNumericScreenPass,false); assert.ok(r.issues.some(i=>i.code==='REVERSED_BOUNDS'));
});
test('drop has both lower rim clearance and upper cup/sled and cup/board constraints', () => {
  const zero=evaluate(set(fixture(),'D','0')); assert.equal(zero.predicates.guardRimClear.status,'NOT_CERTIFIED');
  const tooMuch=set(fixture(),'D','20'); tooMuch.nominal.D='20'; const r=evaluate(tooMuch);
  assert.equal(r.predicates.guardRimClear.status,'CERTIFIED'); assert.equal(r.predicates.cupSledClear.status,'NOT_CERTIFIED'); assert.equal(r.predicates.cupBoardClear.status,'NOT_CERTIFIED'); assert.equal(r.fixedCadCompatible,false); assert.equal(r.scopedNumericScreenPass,false);
});
test('effective face changes do not cancel the fixed world41 rim; fixed 30/23 cup gap retained', () => {
  const r=evaluate(set(fixture(),'Fsafe','40'));
  assert.equal(r.predicates.guardRimClear.signedMarginMm,'-0.950'); assert.equal(r.predicates.cupSledClear.signedMarginMm,'0.550');
});
test('nominal board change updates every relative CAD geometry height and flags incompatibility', () => {
  const x=fixture(); x.nominal.boardTop='16'; x.nominal.SAFE='25'; x.nominal.TRANSFER='4.55'; const r=evaluate(x);
  assert.equal(r.fixedCadCompatible,false); assert.equal(r.nominalGeometry.safeFaceWorldMm,'41.000'); assert.equal(r.nominalGeometry.transferFaceWorldMm,'20.550');
  assert.equal(r.nominalGeometry.drawerRelativeBottomMm,'5.000'); assert.equal(r.nominalGeometry.railRelativeBottomMm,'2.800');
});
test('effective measurements differing from nominal are retained without declaring fixed CAD false', () => {
  const x=set(fixture(),'S','5.6'); x.effective.basis='USER_SUPPLIED_BOUNDS'; const r=evaluate(x);
  assert.equal(r.fixedCadCompatible,true); assert.equal(r.predicates.oldFaceClear.signedMarginMm,'0.150');
  assert.equal(r.physicalMeasurements,'USER_DECLARED_NOT_INDEPENDENTLY_VERIFIED'); assert.equal(r.physicalValidation,'NOT_RUN');
});
test('a common world-Z shift and common datum uncertainty cancel, while differential uncertainty does not', () => {
  const x=fixture(); const coords=['Fsafe','Zblocker','HeadCeiling','RimLoadTop','CupLoadBottom','SledFloorTop','BoardTop','DrawerBottom','RailBottom'];
  for(const key of coords) x.effective.values[key]=(Number(x.effective.values[key])-123.456).toFixed(3);
  x.effective.worldDatum.commonErrorMinus='100'; x.effective.worldDatum.commonErrorPlus='80';
  const r=evaluate(x); for(const k of PREDICATES) assert.equal(r.predicates[k].signedMarginMm,base.predicates[k].signedMarginMm,k);
  const y=fixture(); y.effective.values.U_RimLoadTop_plus='0.1'; assert.equal(margin(y,'guardRimClear'),'-0.050');
});
test('every direct-gap route is equivalent and does not double-charge component errors', () => {
  for(const k of PREDICATES) {
    const x=fixture(); x.effective.routes[k]='DIRECT_LOWER_GAP'; x.effective.directGaps[k]=base.predicates[k].lowerGapBeforeMarginMm;
    const r=evaluate(x); assert.equal(r.predicates[k].signedMarginMm,base.predicates[k].signedMarginMm,k); assert.equal(r.scopedNumericScreenPass,true,k);
  }
  const x=fixture(); x.effective.routes.retractClear='DIRECT_LOWER_GAP'; x.effective.directGaps.retractClear='0.30'; delete x.effective.values.U_R_minus;
  const r=evaluate(x); assert.equal(r.predicates.retractClear.signedMarginMm,'0.100'); assert.equal(r.scopedNumericScreenPass,true);
});
test('fully direct route has no hidden coordinate/uncertainty requirement and never re-adds margins', () => {
  const x=fixture(); x.effective.values={}; delete x.effective.worldDatum;
  for(const k of PREDICATES) { x.effective.routes[k]='DIRECT_LOWER_GAP'; x.effective.directGaps[k]=base.predicates[k].lowerGapBeforeMarginMm; }
  const r=evaluate(x); assert.equal(r.inputValidation,'VALID'); assert.equal(r.scopedNumericScreenPass,true);
  assert.equal(r.transferWindow.status,'NOT_DERIVED_FOR_DIRECT_GAP_ROUTE'); assert.equal(r.railEngagement.status,'UNKNOWN');
});
test('unknown full-sweep population/feature maxima cannot be replaced by central test bounds', () => {
  const x=fixture(); x.effective.scope.drawerSweep='CENTRAL_5X5_ONLY'; x.effective.scope.railSweep='CENTRAL_5X5_ONLY'; const r=evaluate(x);
  assert.equal(r.predicates.drawerClear.status,'UNKNOWN'); assert.equal(r.predicates.railClear.status,'UNKNOWN'); assert.equal(r.scopedNumericScreenPass,false);
  for(const key of ['P_sweep_max','Feature_sweep_max','P_rail_max','Feature_rail_max']) {
    const y=fixture(); delete y.effective.values[key]; assert.equal(evaluate(y).scopedNumericScreenPass,false);
  }
});
test('tall empty pegs fail drawer sweep despite short old beads', () => {
  const x=set(set(fixture(),'H_old_sweep_max','1'),'P_sweep_max','6'); const r=evaluate(x);
  assert.equal(r.predicates.oldFaceClear.status,'CERTIFIED'); assert.equal(r.predicates.drawerClear.signedMarginMm,'-0.350'); assert.equal(r.scopedNumericScreenPass,false);
});
test('rail old-bead restriction must be explicit or included as an obstacle bound', () => {
  const x=fixture(); delete x.effective.scope.noOldBeadsInRail; assert.equal(evaluate(x).predicates.railClear.status,'UNKNOWN');
  x.effective.scope.noOldBeadsInRail=false; x.effective.values.H_old_rail_max='5.1'; assert.equal(evaluate(x).predicates.railClear.signedMarginMm,'-1.650');
  x.effective.scope.noOldBeadsInRail=true; assert.equal(evaluate(x).predicates.railClear.status,'INVALID');
});
test('two-point tilt reading and unknown broader board scope are not whole-footprint certificates', () => {
  const x=fixture(); x.effective.scope.guardTilt='TWO_POINT_READING'; const r=evaluate(x);
  for(const k of ['guardRimClear','cupSledClear','cupBoardClear']) assert.equal(r.predicates[k].status,'UNKNOWN');
  assert.equal(r.scopedNumericScreenPass,false);
  const y=fixture(); y.effective.scope.boardFootprint='LARGER_OR_UNMAPPED_BOARD'; const s=evaluate(y);
  for(const k of ['drawerClear','railClear','cupBoardClear']) assert.equal(s.predicates[k].status,'UNKNOWN');
});
test('missing provenance, datum, route, and design allowance cannot silently default', () => {
  for(const [record,key] of [['provenance','uncertainties'],['worldDatum','id'],['routes','retractClear']]) {
    const x=fixture(); delete x.effective[record][key]; const r=evaluate(x); assert.equal(r.scopedNumericScreenPass,false); assert.equal(r.inputValidation,'INCOMPLETE');
  }
  const x=fixture(); delete x.margins.c_guard; assert.equal(evaluate(x).predicates.guardRimClear.status,'UNKNOWN');
});
test('unknown fields and legacy err cannot silently alias uncertainty or override immutable profile', () => {
  for(const k of ['err','Hmax','SAFE','hardwareTestStatus']) {
    const x=fixture(); x.effective.values[k]='0'; const r=evaluate(x); assert.equal(r.inputValidation,'INVALID'); assert.equal(r.scopedNumericScreenPass,false);
  }
  const x=fixture(); x.nominal.profileId='OTHER'; assert.equal(evaluate(x).fixedCadStatus,'INVALID');
});
test('input fingerprint prevents old results masquerading as new input; output immutable and deterministic', () => {
  assert.equal(evaluate(fixture()).inputFingerprint,base.inputFingerprint);
  assert.notEqual(evaluate(set(fixture(),'R','1.85')).inputFingerprint,base.inputFingerprint);
  assert.throws(()=>{base.predicates.retractClear.status='CERTIFIED_PHYSICALLY';},TypeError);
  const x=fixture(); x.effective.configuration='ADJUSTED_UNCHECKED'; assert.equal(evaluate(x).adjustedConfigurationReview,'NEW_CONFIGURATION_REVIEW_REQUIRED');
});
test('hostile getters, prototypes, proxies, cycles and coercion hooks execute no user code', () => {
  let runs=0;
  const inputs=[new Proxy({}, {ownKeys(){runs++;throw Error('proxy');}}), Object.create({a:1}), Object.defineProperty({},'x',{get(){runs++;return 1;},enumerable:true})];
  const cyc={};cyc.x=cyc;inputs.push(cyc);
  for(const input of inputs) { const r=evaluate(input);assert.equal(r.inputValidation,'INVALID');assert.equal(r.scopedNumericScreenPass,false); }
  assert.equal(runs,0);
  const x=fixture(); x.effective.values.R={valueOf(){runs++;return 2.1;}}; assert.equal(evaluate(x).inputValidation,'INVALID'); assert.equal(runs,0);
});
test('no malformed or incomplete input can set physical status to PASS', () => {
  for(const x of [undefined,null,false,{},[],fixture(),set(fixture(),'R','0')]) {
    const r=evaluate(x);assert.equal(r.physicalValidation,'NOT_RUN'); assert.equal(Object.hasOwn(r,'allPass'),false);
  }
});

test('provided malformed metadata is INVALID even when every predicate uses direct gaps', () => {
  const direct=fixture(); for(const k of PREDICATES) { direct.effective.routes[k]='DIRECT_LOWER_GAP'; direct.effective.directGaps[k]=base.predicates[k].lowerGapBeforeMarginMm; }
  for(const [record,key,bad] of [['worldDatum','id',false],['worldDatum','commonErrorMinus','-1'],['worldDatum','commonErrorPlus',''],['scope','noOldBeadsInRail','yes']]) {
    const x=clone(direct);x.effective[record][key]=bad;const r=evaluate(x);
    assert.equal(r.inputValidation,'INVALID',`${record}.${key}`);assert.equal(r.scopedNumericScreenPass,false,`${record}.${key}`);
  }
});
test('digital hardware counters are fixed zero and unchecked adjustments cannot be interpreted as original CAD approval',()=>{
  for(const x of [null,fixture(),set(fixture(),'R','1.85')]) {
    const r=evaluate(x);assert.equal(r.hardwareTestCount,0);assert.equal(r.hardwareConnected,false);assert.equal(r.physicalValidation,'NOT_RUN');
  }
  const x=fixture();x.effective.configuration='ADJUSTED_UNCHECKED';const r=evaluate(x);
  assert.equal(r.fixedCadCompatible,true);assert.equal(r.scopedNumericScreenPass,true);
  assert.equal(r.effectiveAssemblyCompatibility,'UNCHECKED_ADJUSTMENT_ORIGINAL_CAD_NOT_APPROVAL');
});

test('numbers beyond safe scaled integer precision require exact decimal strings',()=>{
  assert.equal(evaluate(set(fixture(),'Fsafe',9007199254740992)).inputValidation,'INVALID');
  const x=set(fixture(),'Fsafe','9007199254740992');const r=evaluate(x);
  assert.equal(r.inputValidation,'VALID');assert.equal(r.predicates.safeTopClear.status,'NOT_CERTIFIED');
});
test('all twelve required numeric predicates remain mandatory, including direct-gap missing values',()=>{
  for(const k of PREDICATES) {
    const x=fixture();x.effective.routes[k]='DIRECT_LOWER_GAP';
    const r=evaluate(x);assert.equal(r.predicates[k].status,'UNKNOWN');assert.equal(r.scopedNumericScreenPass,false);
  }
  for(const k of INPUT_SCHEMA.marginKeys) {
    const x=fixture();delete x.margins[k];assert.equal(evaluate(x).scopedNumericScreenPass,false,k);
  }
});
