"""Render the separately versioned SmartDrop digital correction guide.

Only explicit guide content enters the PDF. No original HTML, photographs,
conversation export, private notes or historical binary is embedded.
"""
from pathlib import Path
import argparse
import json
import subprocess
from xml.sax.saxutils import escape

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Flowable, KeepTogether

ROOT = Path(__file__).resolve().parent
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
pdfmetrics.registerFont(TTFont('SDLatin', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('SDMono', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))
pdfmetrics.registerFontFamily('STSong-Light', normal='STSong-Light', bold='STSong-Light', italic='STSong-Light', boldItalic='STSong-Light')
BLACK = colors.HexColor('#000000')
MUTED = colors.HexColor('#475569')
WIDTH = A4[0] - 80
STYLES = {
    'title': ParagraphStyle('title', fontName='STSong-Light', fontSize=22, leading=29, textColor=BLACK, wordWrap='CJK', spaceAfter=14),
    'heading': ParagraphStyle('heading', fontName='STSong-Light', fontSize=15, leading=21, textColor=BLACK, wordWrap='CJK', spaceBefore=9, spaceAfter=9),
    'body': ParagraphStyle('body', fontName='STSong-Light', fontSize=10.5, leading=16.5, textColor=BLACK, wordWrap='CJK', spaceAfter=9),
    'small': ParagraphStyle('small', fontName='STSong-Light', fontSize=9, leading=13.5, textColor=MUTED, wordWrap='CJK', spaceAfter=7),
    'equation': ParagraphStyle('equation', fontName='SDMono', fontSize=9, leading=14, textColor=BLACK, wordWrap='CJK', spaceBefore=3, spaceAfter=7),
    'cell': ParagraphStyle('cell', fontName='STSong-Light', fontSize=9, leading=13.5, textColor=BLACK, wordWrap='CJK', alignment=TA_LEFT),
    'celllatin': ParagraphStyle('celllatin', fontName='SDLatin', fontSize=8.5, leading=13.5, textColor=BLACK, wordWrap='CJK'),
    'cellsmall': ParagraphStyle('cellsmall', fontName='STSong-Light', fontSize=8.5, leading=12.5, textColor=BLACK, wordWrap='CJK'),
}


def paragraph(text, style='body'):
    return Paragraph(escape(text).replace('\n', '<br/>'), STYLES[style])


class GeometryFigure(Flowable):
    """A coordinate schematic, not a manufacturing drawing or physical result."""
    def __init__(self):
        super().__init__()
        self.width = WIDTH
        self.height = 255

    def draw(self):
        c = self.canv
        c.setFont('STSong-Light', 9)
        c.setFillColor(BLACK)
        c.drawString(0, 241, '固定原CAD坐标示意  横向位置不按比例  单位 mm')
        c.setStrokeColor(colors.HexColor('#334155'))
        def z(value): return 26 + (value - 15) * 5.4
        c.setLineWidth(1)
        c.line(30, z(15), 470, z(15))
        c.drawString(30, z(15)-16, '普通底板名义表面 world z = 15')
        c.setFillColor(colors.HexColor('#dbeafe'))
        c.rect(66, z(21), 185, z(23)-z(21), fill=1)
        c.setFillColor(BLACK)
        c.drawString(260, z(23)-3, '抽屉顶 23')
        c.setFillColor(colors.HexColor('#cbd5e1'))
        c.rect(85, z(24), 150, z(27)-z(24), fill=1)
        c.setFillColor(BLACK)
        c.drawString(260, z(27), '杯底 = 30 - D')
        c.setFont('SDLatin', 8)
        c.drawString(95, z(25), 'D = 6: z = 24')
        c.setFont('STSong-Light', 9)
        c.line(62, z(41), 242, z(41))
        c.drawString(62, z(41)+8, 'SAFE面 41 = 15 + 26')
        c.setFillColor(colors.HexColor('#e2e8f0'))
        c.rect(349, z(23), 17, z(48.5)-z(23), fill=1)
        c.setFillColor(BLACK)
        c.drawString(377, z(48.5)-4, '挡柱顶 48.50')
        c.line(320, z(50.5), 476, z(50.5))
        c.drawString(292, z(50.5)+8, '托架下表面 50.50 = 41 + 9.50')
        c.setDash(2, 2)
        c.line(251, z(30), 310, z(30))
        c.setDash()
        c.setFont('STSong-Light', 8.5)
        c.drawString(0, 0, '该图解释两处高度差  不包含所有标准件  不证明连续运动无碰撞')


def make_table(item):
    widths = [WIDTH * value for value in item['widths']]
    data = [[paragraph(str(value), 'celllatin' if str(value).isascii() else 'cell') for value in row] for row in item['rows']]
    table = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dbeafe')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')]),
        ('GRID', (0, 0), (-1, -1), 0.45, colors.HexColor('#d9d9d9')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
    ]))
    return [table, Spacer(1, 10)]


def build(content, output):
    output.parent.mkdir(parents=True, exist_ok=True)
    story = []
    for number, page in enumerate(content['pages']):
        if number: story.append(PageBreak())
        story.append(paragraph(page['title'], 'title' if number == 0 else 'heading'))
        for item in page['content']:
            kind = item['type']
            if kind in ('body', 'small', 'heading', 'equation'):
                story.append(paragraph(item['text'], kind))
            elif kind == 'table': story.extend(make_table(item))
            elif kind == 'geometry': story.append(GeometryFigure()); story.append(Spacer(1, 10))
            elif kind == 'example-results':
                raw = subprocess.check_output(['node', '-e', "const c=require('./source/clearance-core.cjs');process.stdout.write(JSON.stringify(c.evaluateClearances(c.makeSyntheticExample())))"], cwd=ROOT, text=True)
                example = json.loads(raw)
                assert example['evidenceLabel'] == 'SYNTHETIC_EXAMPLE'
                assert example['physicalValidation'] == 'NOT_RUN'
                (ROOT/'proof/synthetic-evaluation.json').write_text(json.dumps(example, ensure_ascii=False, indent=2)+'\n')
                rows = [['局部区间项', '最不利余量 mm', '仅此不等式']]
                for key, result in example['predicates'].items():
                    rows.append([key, result['signedMarginMm'], result['status']])
                story.extend(make_table({'widths':[.48,.24,.28], 'rows':rows}))
                window = example['transferWindow']
                story.append(paragraph('Synthetic S window: ['+window['lowerMm']+', '+window['upperMm']+'] mm', 'equation'))
                story.append(paragraph('输入指纹：'+example['inputFingerprint'], 'small'))
            else: raise ValueError('Unsupported explicit content type: ' + kind)
    def header_footer(c, doc):
        c.saveState()
        c.setFillColor(BLACK)
        c.setFont('SDLatin', 8)
        c.drawString(40, A4[1]-27, 'SmartDrop  A5-P0.7-R1  |  DIGITAL REVIEW CORRECTION')
        c.setFont('STSong-Light', 8)
        c.drawString(40, 23, content['footer'])
        c.setFont('SDLatin', 8)
        c.drawRightString(A4[0]-40, 23, str(doc.page))
        c.restoreState()
    document = SimpleDocTemplate(str(output), pagesize=A4, leftMargin=40, rightMargin=40, topMargin=49, bottomMargin=44,
                                 invariant=1, title=content['title'], author='SmartDrop project', subject='Separate digital checker and guide correction; no hardware validation')
    document.build(story, onFirstPage=header_footer, onLaterPages=header_footer)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--content', type=Path, default=ROOT/'guide-content.json')
    parser.add_argument('--out', type=Path, default=ROOT/'output/pdf/SmartDrop_A5_P07_R1_数字校核修订指南.pdf')
    args = parser.parse_args()
    build(json.loads(args.content.read_text()), args.out)
    print(args.out)
