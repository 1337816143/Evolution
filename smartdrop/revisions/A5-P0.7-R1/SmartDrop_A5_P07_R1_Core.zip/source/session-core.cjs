'use strict';

// Separate offline candidate. These are model acknowledgments, not sensors,
// actuator commands, physical test evidence, or a mechanical safety interlock.
const { randomUUID } = require('node:crypto');
const { types: { isProxy } } = require('node:util');

const VERSION = 'A5-P0.7-R1-session';
const MODE = 'SIMULATION_ONLY';
const STAGES = Object.freeze([
  'READY', 'CLAMPED_SUPPORTED', 'GUARD_LOWERED', 'HOLD_ACKNOWLEDGED',
  'DRAWER_WITHDRAWN', 'BLOCKS_REMOVED', 'AT_TRANSFER',
  'RETRACTION_ACKNOWLEDGED', 'LIFTED', 'SUPPORTED', 'AWAY', 'FAULTED'
]);
const EVENTS = Object.freeze([
  'clamp', 'drop', 'hold_ok', 'withdraw', 'remove_blocks', 'lower',
  'retract_ok', 'lift', 'replace_blocks', 'away', 'new_cycle',
  'fault_stop', 'safe_reset'
]);
const FORWARD = Object.freeze({
  clamp: ['READY', 'CLAMPED_SUPPORTED', 'clamp'],
  drop: ['CLAMPED_SUPPORTED', 'GUARD_LOWERED', 'guardLowered'],
  hold_ok: ['GUARD_LOWERED', 'HOLD_ACKNOWLEDGED', 'hold'],
  withdraw: ['HOLD_ACKNOWLEDGED', 'DRAWER_WITHDRAWN', 'drawerWithdrawn'],
  remove_blocks: ['DRAWER_WITHDRAWN', 'BLOCKS_REMOVED', 'blocksRemoved'],
  lower: ['BLOCKS_REMOVED', 'AT_TRANSFER', 'atTransfer'],
  retract_ok: ['AT_TRANSFER', 'RETRACTION_ACKNOWLEDGED', 'retraction'],
  lift: ['RETRACTION_ACKNOWLEDGED', 'LIFTED', 'lift'],
  replace_blocks: ['LIFTED', 'SUPPORTED', 'reSupported'],
  away: ['SUPPORTED', 'AWAY', 'away']
});
const ACK_KEYS = Object.freeze({
  clamp: ['clampSecured', 'safeSupportsInPlace'],
  drop: ['cupLowered', 'boxStationary', 'tiltChecked'],
  hold_ok: ['holdingChecked', 'noDropInModel'],
  withdraw: ['drawerFullyWithdrawn', 'sweepClear'],
  remove_blocks: ['supportsRemoved'],
  lower: ['transferHeightChecked'],
  retract_ok: ['needleRetractionChecked', 'beadReleaseChecked'],
  lift: ['retractionMaintained', 'liftToSafeHeight'],
  replace_blocks: ['reSupported'],
  away: ['awayFromWorkpiece', 'oldColorCheck'],
  new_cycle: ['awayFromWorkpiece', 'reSupported', 'oldColorPresent'],
  fault_stop: ['stopRequested'],
  safe_reset: ['awayFromWorkpiece', 'reSupported', 'faultAddressed', 'oldColorPresent']
});

function fail(message) { throw new TypeError(message); }

// Do not evaluate accessor values or user-defined coercion hooks. Node's
// native Proxy check also prevents traps from running during reflection.
function ownDataRecord(value, expectedKeys, label) {
  if (value === null || typeof value !== 'object' || isProxy(value) ||
      Array.isArray(value)) fail(`${label} must be a plain data record`);
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null)
    fail(`${label} must be a plain data record`);
  const descriptors = Object.getOwnPropertyDescriptors(value);
  const keys = Reflect.ownKeys(descriptors);
  if (keys.length !== expectedKeys.length ||
      keys.some(key => typeof key !== 'string' || !expectedKeys.includes(key)))
    fail(`${label} has missing or unknown fields`);
  const copy = Object.create(null);
  for (const key of expectedKeys) {
    const descriptor = descriptors[key];
    if (!descriptor || !Object.hasOwn(descriptor, 'value'))
      fail(`${label}.${key} must be an own data property`);
    copy[key] = descriptor.value;
  }
  return copy;
}

function frozenCopy(value) {
  if (value === null || typeof value !== 'object') return value;
  const result = Array.isArray(value) ? [] : {};
  for (const key of Object.keys(value)) result[key] = frozenCopy(value[key]);
  return Object.freeze(result);
}

function emptyAcknowledgments() {
  return {
    clamp: null, guardLowered: null, hold: null, drawerWithdrawn: null,
    blocksRemoved: null, atTransfer: null, retraction: null, lift: null,
    reSupported: null, away: null
  };
}

function freshCycle(sessionId, cycleId, revision, oldColorPresent) {
  return {
    version: VERSION, mode: MODE, sessionId, cycleId, revision, stage: 'READY',
    hardwareConnected: false, physicalTest: false, hardwareTestCount: 0,
    hardwareTestStatus: 'NOT_RUN', oldColorUnmoved: null,
    modelOldColorPresent: oldColorPresent, modelOldColorCheck: null,
    acknowledgedInCycle: emptyAcknowledgments(), fault: null
  };
}

function validateAck(type, value) {
  const ack = ownDataRecord(value, ['simulationOnly', ...ACK_KEYS[type]], 'ack');
  if (ack.simulationOnly !== true) fail('ack.simulationOnly must be exactly true');
  for (const key of ACK_KEYS[type]) {
    if (key === 'oldColorPresent') {
      if (typeof ack[key] !== 'boolean') fail('ack.oldColorPresent must be a boolean');
    } else if (key === 'oldColorCheck') {
      if (ack[key] !== 'UNCHANGED' && ack[key] !== 'NOT_APPLICABLE')
        fail('ack.oldColorCheck must be UNCHANGED or NOT_APPLICABLE');
    } else if (ack[key] !== true) fail(`ack.${key} must be exactly true`);
  }
  return ack;
}

function createSession(options) {
  const config = ownDataRecord(options, ['oldColorPresent'], 'options');
  if (typeof config.oldColorPresent !== 'boolean')
    fail('options.oldColorPresent must explicitly select the model scenario');
  let state = frozenCopy(freshCycle(randomUUID(), 1, 0, config.oldColorPresent));
  let advancing = false;

  function snapshot() { return frozenCopy(state); }

  function advance(command) {
    if (arguments.length !== 1) fail('advance accepts exactly one command and no external state');
    if (advancing) fail('reentrant advance is not allowed');
    advancing = true;
    try {
      const event = ownDataRecord(command,
        ['type', 'sessionId', 'cycleId', 'expectedRevision', 'ack'], 'command');
      if (typeof event.type !== 'string' || !EVENTS.includes(event.type))
        fail('unknown event');
      if (typeof event.sessionId !== 'string' || event.sessionId !== state.sessionId)
        fail('foreign session');
      if (!Number.isSafeInteger(event.cycleId) || event.cycleId < 1 ||
          event.cycleId !== state.cycleId) fail('stale or invalid cycleId');
      if (!Number.isSafeInteger(event.expectedRevision) || event.expectedRevision < 0 ||
          event.expectedRevision !== state.revision) fail('stale or invalid expectedRevision');
      const ack = validateAck(event.type, event.ack);
      if (state.revision === Number.MAX_SAFE_INTEGER) fail('revision exhausted');
      const revision = state.revision + 1;
      let next;

      if (event.type === 'fault_stop') {
        if (state.stage === 'FAULTED') fail('fault is already latched');
        next = {
          ...state, stage: 'FAULTED', revision,
          acknowledgedInCycle: emptyAcknowledgments(), modelOldColorCheck: null,
          fault: {
            fromStage: state.stage,
            status: 'SOFTWARE_STOP_ONLY',
            recovery: 'INDEPENDENT_SAFE_ENDPOINT_REQUIRED'
          }
        };
      } else if (event.type === 'new_cycle' || event.type === 'safe_reset') {
        const requiredStage = event.type === 'new_cycle' ? 'AWAY' : 'FAULTED';
        if (state.stage !== requiredStage) fail(`${event.type} requires ${requiredStage}`);
        if (event.type === 'new_cycle' &&
            (state.acknowledgedInCycle.away !== state.cycleId ||
             state.acknowledgedInCycle.reSupported !== state.cycleId))
          fail('current-cycle away and support acknowledgments required');
        if (state.cycleId === Number.MAX_SAFE_INTEGER) fail('cycleId exhausted');
        // A safe_reset records an independently reached endpoint. This code
        // neither prescribes recovery motion nor verifies the physical endpoint.
        next = freshCycle(state.sessionId, state.cycleId + 1, revision, ack.oldColorPresent);
      } else {
        const [from, to, confirmation] = FORWARD[event.type];
        if (state.stage !== from) fail(`${event.type} requires ${from}`);
        if (event.type === 'withdraw' && state.acknowledgedInCycle.hold !== state.cycleId)
          fail('current-cycle holding acknowledgment required');
        if (event.type === 'lift' && state.acknowledgedInCycle.retraction !== state.cycleId)
          fail('current-cycle retraction acknowledgment required');
        if (event.type === 'away') {
          const expected = state.modelOldColorPresent ? 'UNCHANGED' : 'NOT_APPLICABLE';
          if (ack.oldColorCheck !== expected)
            fail(`this model scenario requires oldColorCheck=${expected}`);
        }
        next = {
          ...state, stage: to, revision,
          acknowledgedInCycle: { ...state.acknowledgedInCycle, [confirmation]: state.cycleId }
        };
        if (event.type === 'lower') next.acknowledgedInCycle.retraction = null;
        if (event.type === 'away') next.modelOldColorCheck = ack.oldColorCheck;
      }

      // Prepare both private and public values before committing, so every
      // rejected operation leaves all workflow state and counters unchanged.
      const candidate = frozenCopy(next);
      const result = frozenCopy(candidate);
      state = candidate;
      return result;
    } finally {
      advancing = false;
    }
  }

  return Object.freeze({ snapshot, advance });
}

module.exports = Object.freeze({ VERSION, MODE, STAGES, EVENTS, createSession });
