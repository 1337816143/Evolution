'use strict';
const { types:{isProxy} } = require('node:util');
const VERSION='A5-P0.7-R1-pattern';
function checkArray(value, label){
 if(isProxy(value)||!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw new TypeError(`${label} must be a plain array`);
 const ds=Object.getOwnPropertyDescriptors(value), keys=Reflect.ownKeys(ds);
 if(ds.length.value!==5||keys.length!==6||keys.some(k=>!['0','1','2','3','4','length'].includes(k)))throw new TypeError(`${label} must have exactly five own entries`);
 for(let i=0;i<5;i++)if(!ds[i]||!Object.hasOwn(ds[i],'value'))throw new TypeError(`${label}[${i}] must be an own data entry`);
 return ds;
}
function mirror(pattern){
 const rows=checkArray(pattern,'pattern'), result=[];
 for(let r=0;r<5;r++){
  const cells=checkArray(rows[r].value,`pattern[${r}]`),out=[];
  for(let c=0;c<5;c++){const v=cells[c].value;if(typeof v!=='number'||!Number.isInteger(v)||v<0||v>2)throw new TypeError(`pattern[${r}][${c}] must be 0, 1, or 2`);out[4-c]=v;}
  result.push(out);
 }
 return result;
}
module.exports=Object.freeze({VERSION,mirror});
