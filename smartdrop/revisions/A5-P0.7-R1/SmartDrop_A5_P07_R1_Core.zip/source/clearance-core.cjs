'use strict';

// A separately versioned DIGITAL scalar screen. No actuator interface, physical
// test recorder, actual safety interlock, or claim of complete collision freedom.
const { createHash } = require('node:crypto');
const { types: { isProxy } } = require('node:util');
const VERSION = 'A5-P0.7-R1';
const SCALE = 1000n; // EXACT input/output resolution: 0.001 mm. No epsilon.
const COMPONENT = 'COMPONENT_INTERVALS';
const DIRECT = 'DIRECT_LOWER_GAP';
const PREDICATES = Object.freeze([
  'oldFaceClear', 'tipPegClear', 'capture', 'retractClear', 'safeBlockerClear',
  'safeTopClear', 'guardRimClear', 'cupSledClear', 'cupBoardClear',
  'drawerClear', 'railClear', 'withdrawClear'
]);
const MARGIN_KEYS = Object.freeze(['c_old', 'c_tip', 'c_capture', 'c_retract', 'c_safe',
  'c_top', 'c_guard', 'c_cup', 'c_board', 'c_drawer', 'c_rail', 'c_W']);
function deepFreeze(o) {
  if (o && typeof o === 'object') { Object.values(o).forEach(deepFreeze); Object.freeze(o); }
  return o;
}
const CAD_PROFILE = deepFreeze({
  id: 'A5-P07-FIXED-GEOMETRY', originalRevision: 'A5-P0.7', units: 'mm',
  anchors: { boardTop: '15.000', safeFace: '41.000', transferFace: '20.550',
    carriageUndersideOffset: '9.500', carriageTopOffset: '29.500',
    safeSupportTop: '50.500', transferStopTop: '30.050',
    drawerBottom: '21.000', sledFloorTop: '23.000', blockerTop: '48.500',
    railBottom: '18.800', railTop: '22.000', cupLoadBottom: '30.000',
    rimLoadTop: '41.000', headCeiling: '94.000',
    movingYmax: '48.000', descendingYmin: '-44.000', envelopeThreshold: '92.000' },
  nominal: { boardTop: '15.000', SAFE: '26.000', TRANSFER: '5.550',
    L: '1.650', R: '2.100', D: '6.000', W: '110.000' },
  geometryScope: {
    boardFootprint: 'CAD_145X145_XY_CENTERED', boardBoundsMm: ['-72.500', '72.500'],
    movingBodies: ['G09 sled/blocker', 'G10 cup', 'A07 rim', 'A08 PET', 'modeled cup guide rods', 'modeled cup jack envelopes'],
    descendingBodies: ['G03 carriage', 'G01 mounted frame', 'A01 face', 'A03 back', 'A04 color1 d2.1 needle plate', 'A05 bridge', 'A06 wheel'],
    railY: ['-110.000', '98.000'], runnerY: ['-68.000', '48.000'],
    originalModeledPegField: 'CENTRAL_5X5_ONLY'
  },
  sourceSHA256: {
    originalCore: '78bcc0b3ea3777cd7efdc8df86638cc74c086e2e03a629e06494cd4d1aa802a0',
    originalBuild: '3b42e73861258307d5e05b77ae01a0d23bbe214c0ace6899f8b20c92ae17ac19',
    originalZip: 'ce464848c12491febf28a66552a23d75250fca983ae2ab6a9786ce8b24428965'
  }
});
const VALUE_KEYS = Object.freeze([
  'H_old_max', 'H_new_min', 'H_new_max', 'P_transfer_min', 'P_transfer_max',
  'H_old_sweep_max', 'P_sweep_max', 'Feature_sweep_max', 'P_rail_max',
  'Feature_rail_max', 'H_old_rail_max', 'ObstacleCup_max',
  'S', 'U_S_minus', 'U_S_plus', 'L', 'U_L_plus', 'R', 'U_R_minus',
  'Fsafe', 'U_Fsafe_minus', 'U_Fsafe_plus', 'D', 'U_D_minus', 'U_D_plus',
  'W', 'U_W_minus', 'U_Y', 'T_up', 'T_down',
  'Kcar', 'U_Kcar_minus', 'Zblocker', 'U_Zblocker_plus',
  'KcarTop', 'U_KcarTop_plus', 'HeadCeiling', 'U_HeadCeiling_minus',
  'RimLoadTop', 'U_RimLoadTop_plus', 'CupLoadBottom', 'U_CupLoadBottom_minus',
  'SledFloorTop', 'U_SledFloorTop_plus', 'BoardTop', 'U_BoardTop_plus',
  'DrawerBottom', 'U_DrawerBottom_minus', 'RailBottom', 'U_RailBottom_minus'
]);
const SIGNED_VALUES = new Set(['S', 'Fsafe', 'Zblocker', 'HeadCeiling', 'RimLoadTop',
  'CupLoadBottom', 'SledFloorTop', 'BoardTop', 'DrawerBottom', 'RailBottom']);
const PROVENANCE_KEYS = ['dimensions', 'uncertainties', 'populationBounds', 'geometry', 'tilt', 'sweepCoverage'];
const SCOPE_KEYS = ['transfer', 'hangingNewBeads', 'drawerSweep', 'railSweep', 'cupSweep',
  'guardTilt', 'geometry', 'boardFootprint', 'withdrawalDirection', 'motion', 'noOldBeadsInRail'];
const NOMINAL_KEYS = ['profileId', ...Object.keys(CAD_PROFILE.nominal)];
const INPUT_SCHEMA = deepFreeze({
  version: VERSION, units: 'mm', resolutionMm: '0.001',
  numericGrammar: 'trimmed [+-]?digits[.1-to-3-digits]; finite ordinary decimal numbers also accepted; no exponents or coercion',
  missing: 'UNKNOWN; explicit null/blank/boolean/nonfinite/object/array is INVALID',
  nominalKeys: NOMINAL_KEYS, valueKeys: VALUE_KEYS, marginKeys: MARGIN_KEYS,
  routeKeys: PREDICATES, routes: [COMPONENT, DIRECT],
  provenanceKeys: PROVENANCE_KEYS, scopeKeys: SCOPE_KEYS,
  directGapSemantics: {
    oldFaceClear: 'min(face-to-board minus seated-old-bead top), before c_old',
    tipPegClear: 'min(face-to-board minus exposure minus transfer peg height), before c_tip',
    capture: 'min(transfer peg height plus new-bead axial height minus face-to-board), before c_capture',
    retractClear: 'min(relative retract stroke minus exposure), before c_retract',
    safeBlockerClear: 'min(carriage underside minus blocker top), before c_safe',
    safeTopClear: 'min(ceiling underside minus carriage top), before c_top',
    guardRimClear: 'min(hanging bead bottom minus every rim point after drop), before c_guard',
    cupSledClear: 'min(every cup underside point after drop minus sled floor), before c_cup',
    cupBoardClear: 'min(every cup underside point after drop minus every board obstacle in its footprint), before c_board',
    drawerClear: 'min(board-overlapping drawer underside minus every obstacle over the entire declared sweep), before c_drawer',
    railClear: 'min(rail underside minus every included obstacle over its entire footprint), before c_rail',
    withdrawClear: 'min(descending ymin minus withdrawn moving ymax), before c_W'
  }
});

function parseMm(v) {
  if (typeof v !== 'string' && typeof v !== 'number') throw new TypeError('not a decimal scalar');
  if (typeof v === 'number' && !Number.isFinite(v)) throw new TypeError('nonfinite number');
  const s = String(v).trim();
  if (s.length > 32 || !/^[+-]?\d+(?:\.\d{1,3})?$/.test(s))
    throw new TypeError('expected explicit decimal with at most 3 fractional digits');
  const neg = s.startsWith('-');
  const [whole, frac = ''] = s.replace(/^[+-]/, '').split('.');
  const n = (neg ? -1n : 1n) * (BigInt(whole) * SCALE + BigInt(frac.padEnd(3, '0')));
  if (typeof v === 'number' && (n > BigInt(Number.MAX_SAFE_INTEGER) || n < -BigInt(Number.MAX_SAFE_INTEGER)))
    throw new TypeError('numeric input exceeds safe scaled resolution; use an exact decimal string');
  return n;
}
function formatMm(n) {
  const a = n < 0n ? -n : n;
  return `${n < 0n ? '-' : ''}${a / SCALE}.${String(a % SCALE).padStart(3, '0')}`;
}
const min = (...a) => a.reduce((x, y) => x < y ? x : y);
const max = (...a) => a.reduce((x, y) => x > y ? x : y);

// Accept only inert records: do not invoke coercion hooks, accessors, or proxies.
function inertCopy(value, seen = new Set(), depth = 0) {
  if (value === null || ['string', 'number', 'boolean', 'undefined'].includes(typeof value)) return value;
  if (typeof value !== 'object' || isProxy(value) || Array.isArray(value) || depth > 10 || seen.has(value))
    throw new TypeError('input must contain only acyclic plain data records and scalar values');
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) throw new TypeError('input record has a non-data prototype');
  const out = Object.create(null);
  seen.add(value);
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== 'string') throw new TypeError('symbol fields are not supported');
    const d = Object.getOwnPropertyDescriptor(value, key);
    if (!Object.hasOwn(d, 'value')) throw new TypeError('accessor fields are not supported');
    out[key] = inertCopy(d.value, seen, depth + 1);
  }
  seen.delete(value);
  return out;
}
function canonical(v) {
  if (v === undefined) return 'undefined';
  if (typeof v === 'number' && !Number.isFinite(v)) return String(v);
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  return `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;
}

function evaluateClearances(input) {
  let data;
  const issues = [], issueIds = new Set(), invalidPaths = new Set(), cache = new Map();
  const add = (path, code, message, status = 'INVALID') => {
    const id = `${path}:${code}`;
    if (!issueIds.has(id)) { issueIds.add(id); issues.push({ path, code, status, message }); }
    if (status === 'INVALID') invalidPaths.add(path);
  };
  try { data = inertCopy(input); } catch (e) {
    return deepFreeze({ version: VERSION, units: 'mm', inputFingerprint: null,
      fixedCadCompatible: false, fixedCadStatus: 'INVALID', scopedNumericScreenPass: false,
      physicalValidation: 'NOT_RUN', hardwareTestCount: 0, hardwareConnected: false, physicalMeasurements: 'NOT_RECEIVED',
      inputValidation: 'INVALID', predicates: Object.fromEntries(PREDICATES.map(k => [k, { status: 'INVALID', signedMarginMm: null }])),
      issues: [{ path: '$', code: 'NON_DATA_INPUT', status: 'INVALID', message: e.message }] });
  }
  const get = p => p.split('.').reduce((o, k) => o && typeof o === 'object' && Object.hasOwn(o, k) ? o[k] : undefined, data);
  const missing = p => { add(p, 'MISSING', 'Required information has not been supplied', 'UNKNOWN'); return null; };
  function shape(p, keys) {
    const v = p === '$' ? data : get(p);
    if (v === undefined) return;
    if (!v || typeof v !== 'object') { add(p, 'INVALID_RECORD', 'Expected a plain record'); return; }
    for (const k of Object.keys(v)) if (!keys.includes(k)) add(p === '$' ? k : `${p}.${k}`, 'UNKNOWN_FIELD', 'Unknown field; implicit aliases and legacy err are not accepted');
  }
  shape('$', ['version', 'nominal', 'effective', 'margins']);
  shape('nominal', NOMINAL_KEYS);
  shape('effective', ['basis', 'configuration', 'uncertaintyModel', 'worldDatum', 'provenance', 'scope', 'values', 'routes', 'directGaps']);
  shape('effective.worldDatum', ['id', 'commonErrorMinus', 'commonErrorPlus']);
  shape('effective.provenance', PROVENANCE_KEYS); shape('effective.scope', SCOPE_KEYS);
  shape('effective.values', VALUE_KEYS); shape('effective.routes', PREDICATES);
  shape('effective.directGaps', PREDICATES); shape('margins', MARGIN_KEYS);
  function number(p, signed = false) {
    if (cache.has(p)) return cache.get(p);
    const v = get(p); let n = null;
    if (v === undefined) missing(p);
    else try {
      n = parseMm(v);
      if (!signed && n < 0n) { add(p, 'NEGATIVE_BOUND', 'This magnitude, uncertainty, or margin must be nonnegative'); n = null; }
    } catch (e) { add(p, 'INVALID_DECIMAL', e.message); }
    cache.set(p, n); return n;
  }
  function text(p, options) {
    const v = get(p);
    if (v === undefined) return missing(p);
    if (typeof v !== 'string' || !v.trim() || (options && !options.includes(v))) {
      add(p, 'INVALID_LABEL', options ? `Expected one of ${options.join(', ')}` : 'Expected a nonempty provenance string'); return null;
    }
    return v;
  }
  function scope(key, expected, incomplete = ['UNKNOWN', 'CENTRAL_5X5_ONLY', 'TWO_POINT_READING', 'LARGER_OR_UNMAPPED_BOARD']) {
    const p = `effective.scope.${key}`, v = get(p);
    if (v === undefined) return missing(p);
    if (v === expected) return true;
    if (incomplete.includes(v)) { add(p, 'INSUFFICIENT_SCOPE', `This predicate requires ${expected}`, 'UNKNOWN'); return null; }
    add(p, 'INVALID_SCOPE', `Expected ${expected}`); return null;
  }
  function statusFor(paths) {
    const relevant = issues.filter(i => paths.some(p => i.path === p || i.path.startsWith(`${p}.`)));
    return relevant.some(i => i.status === 'INVALID') ? 'INVALID' : 'UNKNOWN';
  }
  // Reject malformed supplied numbers even when an alternate route would not use them.
  for (const k of VALUE_KEYS) if (get(`effective.values.${k}`) !== undefined) number(`effective.values.${k}`, SIGNED_VALUES.has(k));
  for (const k of MARGIN_KEYS) if (get(`margins.${k}`) !== undefined) number(`margins.${k}`);
  for (const k of PREDICATES) if (get(`effective.directGaps.${k}`) !== undefined) number(`effective.directGaps.${k}`, true);
  for (const [low, high] of [['H_new_min', 'H_new_max'], ['P_transfer_min', 'P_transfer_max'], ['Kcar', 'KcarTop']]) {
    const lp = `effective.values.${low}`, hp = `effective.values.${high}`;
    if (get(lp) !== undefined && get(hp) !== undefined) {
      const l = number(lp, SIGNED_VALUES.has(low)), h = number(hp, SIGNED_VALUES.has(high));
      if (l !== null && h !== null && l > h) {
        add(lp, 'REVERSED_BOUNDS', `${low} exceeds ${high}`); add(hp, 'REVERSED_BOUNDS', `${high} is less than ${low}`);
        cache.set(lp, null); cache.set(hp, null);
      }
    }
  }
  // Validate supplied metadata even when the chosen direct route does not use it.
  if (get('effective.worldDatum.id') !== undefined) text('effective.worldDatum.id');
  for (const k of ['commonErrorMinus', 'commonErrorPlus']) {
    const p = `effective.worldDatum.${k}`; if (get(p) !== undefined) number(p);
  }
  const noOldProvided = get('effective.scope.noOldBeadsInRail');
  if (noOldProvided !== undefined && typeof noOldProvided !== 'boolean')
    add('effective.scope.noOldBeadsInRail', 'INVALID_BOOLEAN', 'Explicit no-old-beads restriction must be boolean');
  if (noOldProvided === true && get('effective.values.H_old_rail_max') !== undefined &&
      number('effective.values.H_old_rail_max') !== null && number('effective.values.H_old_rail_max') !== 0n)
    add('effective.scope.noOldBeadsInRail', 'CONTRADICTORY_SCOPE', 'Nonzero old-bead height conflicts with no-old-beads rail restriction');
  const commonPaths = ['version', 'effective.basis', 'effective.configuration', 'effective.uncertaintyModel', 'effective.provenance'];
  const common = [text('version', [VERSION]), text('effective.basis', ['SYNTHETIC_EXAMPLE', 'USER_SUPPLIED_BOUNDS']),
    text('effective.configuration', ['ORIGINAL_ASSEMBLY_UNMODIFIED', 'ADJUSTED_UNCHECKED']),
    text('effective.uncertaintyModel', ['RECTANGULAR_BOUNDS_SHARED_WORLD_Z_DATUM']),
    ...PROVENANCE_KEYS.map(k => text(`effective.provenance.${k}`))];
  const nominalNumbers = {};
  const profile = text('nominal.profileId', [CAD_PROFILE.id]);
  for (const k of Object.keys(CAD_PROFILE.nominal)) nominalNumbers[k] = number(`nominal.${k}`, ['boardTop', 'SAFE', 'TRANSFER'].includes(k));
  const nominalComplete = profile !== null && Object.values(nominalNumbers).every(v => v !== null);
  const nominalMatches = nominalComplete && Object.entries(nominalNumbers).every(([k, v]) => v === parseMm(CAD_PROFILE.nominal[k]));
  const fixedCadCompatible = Boolean(nominalMatches && !issues.some(i => i.path.startsWith('nominal.') && i.status === 'INVALID'));
  const fixedCadStatus = issues.some(i => i.path.startsWith('nominal.') && i.status === 'INVALID') ? 'INVALID' : nominalComplete ? (fixedCadCompatible ? 'COMPATIBLE' : 'INCOMPATIBLE') : statusFor(['nominal']);
  let nominalGeometry = null;
  if (nominalComplete) {
    const n = nominalNumbers, f = n.boardTop + n.SAFE, ft = n.boardTop + n.TRANSFER;
    nominalGeometry = {
      status: 'EXACT_DECLARED_NOMINAL_MATH_ONLY', safeFaceWorldMm: formatMm(f), transferFaceWorldMm: formatMm(ft),
      fixedRimLoadTopWorldMm: '41.000', fixedCupLoadBottomWorldMm: '30.000', fixedSledFloorTopWorldMm: '23.000',
      safeBlockerGapMm: formatMm(f + 9500n - 48500n), upperHeadroomMm: formatMm(94000n - f - 29500n),
      faceToDroppedRimGapMm: formatMm(f - 41000n + n.D), cupToSledGapMm: formatMm(30000n - n.D - 23000n),
      withdrawalYGapMm: formatMm(n.W - 92000n),
      safeSupportMismatchMm: formatMm(f + 9500n - 50500n),
      transferSupportMismatchMm: formatMm(ft + 9500n - 30050n), loadRimContactMismatchMm: formatMm(f - 41000n),
      drawerRelativeBottomMm: formatMm(21000n - n.boardTop), railRelativeBottomMm: formatMm(18800n - n.boardTop)
    };
  }
  const datumPaths = ['effective.worldDatum'];
  let datumCache;
  function datum() {
    if (!datumCache) datumCache = [text('effective.worldDatum.id'), number('effective.worldDatum.commonErrorMinus'), number('effective.worldDatum.commonErrorPlus')];
    return datumCache.every(v => v !== null);
  }
  const geometryScope = ['geometry', 'LISTED_CAD_BODIES'];
  const boardScope = ['boardFootprint', 'CAD_145X145_XY_CENTERED'];
  const tiltScope = ['guardTilt', 'FULL_FOOTPRINT_BOUND'];
  const motionScope = ['motion', 'PURE_TRANSLATION'];
  const transferScope = ['transfer', 'INTENDED_TRANSFER_SITES'];
  const scopes = {
    oldFaceClear: [transferScope], tipPegClear: [transferScope], capture: [transferScope], retractClear: [],
    safeBlockerClear: [geometryScope, motionScope], safeTopClear: [geometryScope],
    guardRimClear: [geometryScope, tiltScope, ['hangingNewBeads', 'INCLUDING_SAG_AND_SEATING']],
    cupSledClear: [geometryScope, tiltScope],
    cupBoardClear: [geometryScope, boardScope, tiltScope, ['cupSweep', 'ENTIRE_CUP_FOOTPRINT']],
    drawerClear: [geometryScope, boardScope, ['drawerSweep', 'ENTIRE_DECLARED_SWEEP']],
    railClear: [geometryScope, boardScope, ['railSweep', 'ENTIRE_DECLARED_RAIL_FOOTPRINT']],
    withdrawClear: [geometryScope, motionScope, ['withdrawalDirection', 'NEGATIVE_Y']]
  };
  const defs = {
    oldFaceClear: ['c_old', ['S', 'U_S_minus', 'H_old_max'], v => v.S-v.U_S_minus-v.H_old_max, 'S - U_S_minus - H_old_max - c_old'],
    tipPegClear: ['c_tip', ['S', 'U_S_minus', 'L', 'U_L_plus', 'P_transfer_max'], v => v.S-v.U_S_minus-v.L-v.U_L_plus-v.P_transfer_max, 'S - U_S_minus - L - U_L_plus - P_transfer_max - c_tip'],
    capture: ['c_capture', ['P_transfer_min', 'H_new_min', 'S', 'U_S_plus'], v => v.P_transfer_min+v.H_new_min-v.S-v.U_S_plus, 'P_transfer_min + H_new_min - S - U_S_plus - c_capture'],
    retractClear: ['c_retract', ['R', 'U_R_minus', 'L', 'U_L_plus'], v => v.R-v.U_R_minus-v.L-v.U_L_plus, 'R - U_R_minus - L - U_L_plus - c_retract'],
    safeBlockerClear: ['c_safe', ['Fsafe', 'U_Fsafe_minus', 'Kcar', 'U_Kcar_minus', 'Zblocker', 'U_Zblocker_plus'], v => v.Fsafe-v.U_Fsafe_minus+v.Kcar-v.U_Kcar_minus-v.Zblocker-v.U_Zblocker_plus, 'Fsafe - U_Fsafe_minus + Kcar - U_Kcar_minus - Zblocker - U_Zblocker_plus - c_safe', true],
    safeTopClear: ['c_top', ['HeadCeiling', 'U_HeadCeiling_minus', 'Fsafe', 'U_Fsafe_plus', 'KcarTop', 'U_KcarTop_plus'], v => v.HeadCeiling-v.U_HeadCeiling_minus-v.Fsafe-v.U_Fsafe_plus-v.KcarTop-v.U_KcarTop_plus, 'HeadCeiling - U_HeadCeiling_minus - Fsafe - U_Fsafe_plus - KcarTop - U_KcarTop_plus - c_top', true],
    guardRimClear: ['c_guard', ['Fsafe', 'U_Fsafe_minus', 'H_new_max', 'RimLoadTop', 'U_RimLoadTop_plus', 'D', 'U_D_minus', 'T_up'], v => v.Fsafe-v.U_Fsafe_minus-v.H_new_max-v.RimLoadTop-v.U_RimLoadTop_plus+v.D-v.U_D_minus-v.T_up, 'Fsafe - U_Fsafe_minus - H_new_max - RimLoadTop - U_RimLoadTop_plus + D - U_D_minus - T_up - c_guard', true],
    cupSledClear: ['c_cup', ['CupLoadBottom', 'U_CupLoadBottom_minus', 'D', 'U_D_plus', 'T_down', 'SledFloorTop', 'U_SledFloorTop_plus'], v => v.CupLoadBottom-v.U_CupLoadBottom_minus-v.D-v.U_D_plus-v.T_down-v.SledFloorTop-v.U_SledFloorTop_plus, 'CupLoadBottom - U_CupLoadBottom_minus - D - U_D_plus - T_down - SledFloorTop - U_SledFloorTop_plus - c_cup', true],
    cupBoardClear: ['c_board', ['CupLoadBottom', 'U_CupLoadBottom_minus', 'D', 'U_D_plus', 'T_down', 'BoardTop', 'U_BoardTop_plus', 'ObstacleCup_max'], v => v.CupLoadBottom-v.U_CupLoadBottom_minus-v.D-v.U_D_plus-v.T_down-v.BoardTop-v.U_BoardTop_plus-v.ObstacleCup_max, 'CupLoadBottom - U_CupLoadBottom_minus - D - U_D_plus - T_down - BoardTop - U_BoardTop_plus - ObstacleCup_max - c_board', true],
    drawerClear: ['c_drawer', ['DrawerBottom', 'U_DrawerBottom_minus', 'BoardTop', 'U_BoardTop_plus', 'H_old_sweep_max', 'P_sweep_max', 'Feature_sweep_max'], v => v.DrawerBottom-v.U_DrawerBottom_minus-v.BoardTop-v.U_BoardTop_plus-max(v.H_old_sweep_max,v.P_sweep_max,v.Feature_sweep_max), 'DrawerBottom - U_DrawerBottom_minus - BoardTop - U_BoardTop_plus - max(H_old_sweep_max, P_sweep_max, Feature_sweep_max) - c_drawer', true],
    railClear: ['c_rail', ['RailBottom', 'U_RailBottom_minus', 'BoardTop', 'U_BoardTop_plus', 'P_rail_max', 'Feature_rail_max'], v => v.RailBottom-v.U_RailBottom_minus-v.BoardTop-v.U_BoardTop_plus-max(v.P_rail_max,v.Feature_rail_max,v.H_old_rail_max ?? 0n), 'RailBottom - U_RailBottom_minus - BoardTop - U_BoardTop_plus - max(P_rail_max, Feature_rail_max, included H_old_rail_max) - c_rail', true],
    withdrawClear: ['c_W', ['W', 'U_W_minus', 'U_Y'], v => v.W-v.U_W_minus-92000n-v.U_Y, 'W - U_W_minus - 92 - U_Y - c_W']
  };
  const predicates = {};
  for (const key of PREDICATES) {
    const [marginKey, baseKeys, fn, formula, usesDatum] = defs[key];
    const routePath = `effective.routes.${key}`;
    const route = text(routePath, [COMPONENT, DIRECT]);
    const margin = number(`margins.${marginKey}`);
    const paths = [...commonPaths, routePath, `margins.${marginKey}`, ...scopes[key].map(([k]) => `effective.scope.${k}`)];
    const scoped = scopes[key].map(([k, expected]) => scope(k, expected));
    let ready = common.every(v => v !== null) && scoped.every(v => v === true) && margin !== null && route !== null;
    let gap = null;
    if (route === DIRECT) {
      const p = `effective.directGaps.${key}`; paths.push(p); gap = number(p, true); ready &&= gap !== null;
    } else if (route === COMPONENT) {
      const keys = [...baseKeys];
      if (key === 'railClear') {
        const p = 'effective.scope.noOldBeadsInRail'; paths.push(p); const noOld = get(p);
        if (noOld === undefined) { missing(p); ready = false; }
        else if (typeof noOld !== 'boolean') { add(p, 'INVALID_BOOLEAN', 'Explicit no-old-beads restriction must be boolean'); ready = false; }
        else if (!noOld) keys.push('H_old_rail_max');
        else if (get('effective.values.H_old_rail_max') !== undefined && number('effective.values.H_old_rail_max') !== 0n) {
          add(p, 'CONTRADICTORY_SCOPE', 'Nonzero old-bead height conflicts with no-old-beads rail restriction'); ready = false;
        }
      }
      const values = {};
      for (const k of keys) { const p = `effective.values.${k}`; paths.push(p); values[k] = number(p, SIGNED_VALUES.has(k)); }
      if (usesDatum) { paths.push(...datumPaths); ready = datum() && ready; }
      ready &&= Object.values(values).every(v => v !== null);
      if (ready) gap = fn(values);
    }
    // Unknown/extra schema fields invalidate the input globally, never grant a pass.
    if (paths.some(p => invalidPaths.has(p))) ready = false;
    const signed = ready ? gap - margin : null;
    predicates[key] = {
      status: ready ? (signed >= 0n ? 'CERTIFIED' : 'NOT_CERTIFIED') : statusFor(paths),
      units: 'mm', route, inputKeys: paths, lowerGapBeforeMarginMm: ready ? formatMm(gap) : null,
      designMarginMm: margin === null ? null : formatMm(margin), signedMarginMm: signed === null ? null : formatMm(signed),
      formula: route === DIRECT ? `directGaps.${key} - ${marginKey}` : formula,
      scope: scopes[key].map(([k, expected]) => ({ key: k, required: expected })),
      interpretation: key === 'withdrawClear' ? 'Conservative Y-plane certificate only; failure is not a collision witness or minimum-stroke proof' : 'Scoped bounded scalar certificate only; failure need not imply actual overlap'
    };
  }
  // Derive the component-based S window only when that representation is complete.
  const windowKeys = ['S', 'U_S_minus', 'U_S_plus', 'H_old_max', 'L', 'U_L_plus', 'P_transfer_max', 'P_transfer_min', 'H_new_min'];
  let transferWindow = { status: 'UNKNOWN', lowerMm: null, upperMm: null, validWindow: false, withinWindow: false };
  if (['oldFaceClear', 'tipPegClear', 'capture'].every(k => get(`effective.routes.${k}`) === COMPONENT)) {
    const v = Object.fromEntries(windowKeys.map(k => [k, number(`effective.values.${k}`, SIGNED_VALUES.has(k))]));
    const mo = number('margins.c_old'), mt = number('margins.c_tip'), mc = number('margins.c_capture');
    if ([...Object.values(v), mo, mt, mc].every(x => x !== null)) {
      const lower = max(v.H_old_max+mo, v.L+v.U_L_plus+v.P_transfer_max+mt)+v.U_S_minus;
      const upper = v.P_transfer_min+v.H_new_min-mc-v.U_S_plus;
      transferWindow = { status: lower <= upper ? 'NONEMPTY' : 'EMPTY', lowerMm: formatMm(lower), upperMm: formatMm(upper),
        validWindow: lower <= upper, withinWindow: lower <= v.S && v.S <= upper };
    } else transferWindow.status = statusFor(windowKeys.map(k => `effective.values.${k}`));
  } else transferWindow.status = 'NOT_DERIVED_FOR_DIRECT_GAP_ROUTE';
  let railEngagement = { status: 'UNKNOWN', nominalAtDeclaredStrokeMm: null, stability: 'NOT_ESTABLISHED' };
  const w = get('effective.values.W') === undefined ? null : number('effective.values.W');
  if (w !== null) {
    const overlap = max(0n, min(98000n,48000n-w)-max(-110000n,-68000n-w));
    railEngagement = { status: overlap === 0n ? 'NO_NOMINAL_OVERLAP' : 'POSITIVE_NOMINAL_OVERLAP_ONLY',
      nominalAtDeclaredStrokeMm: formatMm(overlap), stability: 'NOT_ESTABLISHED',
      warning: 'No rated engagement length or upper achieved-stroke uncertainty supplied; positive nominal overlap is not a support or strength certification' };
  }
  const inputValidation = issues.some(i => i.status === 'INVALID') ? 'INVALID' : issues.some(i => i.status === 'UNKNOWN') ? 'INCOMPLETE' : 'VALID';
  const scopedNumericScreenPass = inputValidation === 'VALID' && PREDICATES.every(k => predicates[k].status === 'CERTIFIED');
  return deepFreeze({
    version: VERSION, mode: 'DIGITAL_ONLY', units: 'mm', resolutionMm: '0.001',
    inputFingerprint: createHash('sha256').update(canonical(data)).digest('hex'),
    evidenceLabel: get('effective.basis') ?? 'UNSPECIFIED',
    fixedCadCompatible, fixedCadStatus, nominalGeometry,
    effectiveConfiguration: get('effective.configuration') ?? 'UNKNOWN',
    effectiveAssemblyCompatibility: get('effective.configuration') === 'ADJUSTED_UNCHECKED'
      ? 'UNCHECKED_ADJUSTMENT_ORIGINAL_CAD_NOT_APPROVAL'
      : fixedCadCompatible ? 'ORIGINAL_NOMINAL_ONLY_MEASUREMENTS_NOT_VERIFIED' : 'DECLARED_NOMINAL_OUTSIDE_FIXED_CAD',
    adjustedConfigurationReview: get('effective.configuration') === 'ADJUSTED_UNCHECKED' ? 'NEW_CONFIGURATION_REVIEW_REQUIRED' : 'NO_ADJUSTMENT_DECLARED',
    inputValidation, scopedNumericScreenPass, physicalValidation: 'NOT_RUN', hardwareTestCount: 0, hardwareConnected: false,
    physicalMeasurements: get('effective.basis') === 'USER_SUPPLIED_BOUNDS' ? (inputValidation === 'VALID' ? 'USER_DECLARED_NOT_INDEPENDENTLY_VERIFIED' : 'NOT_RECEIVED_OR_INCOMPLETE') : 'NOT_RECEIVED',
    predicates, transferWindow, railEngagement, issues,
    limits: [
      'No hardware tests, bead retention/release tests, or actual complete-machine collision proof were run',
      '92 mm is a conservative envelope threshold; 110 mm remains the only supplied withdrawn pose',
      'Nominal geometry, effective bounds, historical finite CAD samples, and physical validation are distinct',
      'The 21 mm underside applies only to the stated board footprint and named drawer solids, not every moving component or a larger board',
      'All measured declarations and provenance are user-supplied; this calculator does not independently validate them',
      'Shared world-Z datum error cancels only in same-datum coordinate differences; separate differential uncertainties remain',
      'Input changes require a fresh evaluation; a fingerprint is not a hardware authorization or safety token'
    ]
  });
}

function makeSyntheticExample() {
  const values = {
    H_old_max: '5.10', H_new_min: '4.90', H_new_max: '5.10', P_transfer_min: '2.70', P_transfer_max: '3.10',
    H_old_sweep_max: '5.10', P_sweep_max: '3.10', Feature_sweep_max: '0', P_rail_max: '3.10', Feature_rail_max: '0', H_old_rail_max: '0', ObstacleCup_max: '5.10',
    S: '5.55', U_S_minus: '0.15', U_S_plus: '0.15', L: '1.65', U_L_plus: '0.05', R: '2.10', U_R_minus: '0.10',
    Fsafe: '41', U_Fsafe_minus: '0.10', U_Fsafe_plus: '0.10', D: '6', U_D_minus: '0.05', U_D_plus: '0.05',
    W: '110', U_W_minus: '0.50', U_Y: '0.20', T_up: '0.20', T_down: '0.20',
    Kcar: '9.50', U_Kcar_minus: '0', Zblocker: '48.50', U_Zblocker_plus: '0', KcarTop: '29.50', U_KcarTop_plus: '0', HeadCeiling: '94', U_HeadCeiling_minus: '0',
    RimLoadTop: '41', U_RimLoadTop_plus: '0', CupLoadBottom: '30', U_CupLoadBottom_minus: '0', SledFloorTop: '23', U_SledFloorTop_plus: '0',
    BoardTop: '15', U_BoardTop_plus: '0', DrawerBottom: '21', U_DrawerBottom_minus: '0.15', RailBottom: '18.80', U_RailBottom_minus: '0.15'
  };
  return {
    version: VERSION, nominal: { profileId: CAD_PROFILE.id, ...CAD_PROFILE.nominal },
    effective: {
      basis: 'SYNTHETIC_EXAMPLE', configuration: 'ORIGINAL_ASSEMBLY_UNMODIFIED', uncertaintyModel: 'RECTANGULAR_BOUNDS_SHARED_WORLD_Z_DATUM',
      worldDatum: { id: 'SYNTHETIC_COMMON_WORLD_Z', commonErrorMinus: '0', commonErrorPlus: '0' },
      provenance: Object.fromEntries(PROVENANCE_KEYS.map(k => [k, 'SYNTHETIC_EXAMPLE: invented software regression bounds, not measurements or recommended manufacturing tolerances'])),
      scope: { transfer: 'INTENDED_TRANSFER_SITES', hangingNewBeads: 'INCLUDING_SAG_AND_SEATING',
        drawerSweep: 'ENTIRE_DECLARED_SWEEP', railSweep: 'ENTIRE_DECLARED_RAIL_FOOTPRINT', cupSweep: 'ENTIRE_CUP_FOOTPRINT',
        guardTilt: 'FULL_FOOTPRINT_BOUND', geometry: 'LISTED_CAD_BODIES', boardFootprint: 'CAD_145X145_XY_CENTERED',
        withdrawalDirection: 'NEGATIVE_Y', motion: 'PURE_TRANSLATION', noOldBeadsInRail: true },
      values, routes: Object.fromEntries(PREDICATES.map(k => [k, COMPONENT])), directGaps: {}
    },
    margins: { c_old: '0.20', c_tip: '0.30', c_capture: '0.80', c_retract: '0.20', c_safe: '0.20', c_top: '0.20',
      c_guard: '0.50', c_cup: '0.20', c_board: '0.20', c_drawer: '0.20', c_rail: '0.20', c_W: '1.00' }
  };
}
module.exports = Object.freeze({ VERSION, CAD_PROFILE, INPUT_SCHEMA, PREDICATES, evaluateClearances, makeSyntheticExample });
